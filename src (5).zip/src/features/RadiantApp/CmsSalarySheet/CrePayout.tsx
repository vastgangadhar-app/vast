import React, { useEffect, useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    ScrollView,
    Button,
} from "react-native";
import AppBarSecond from "../../drawer/headerAppbar/AppBarSecond";
import CalendarCmssvg from "../../drawer/svgimgcomponents/CalendarCmssvg";
import { hScale, wScale } from "../../../utils/styles/dimensions";
import { useSelector } from "react-redux";
import { RootState } from "../../../reduxUtils/store";
import useAxiosHook from "../../../utils/network/AxiosClient";
import { APP_URLS } from "../../../utils/network/urls";

export default function CrePayout() {
    const { post } = useAxiosHook();
    const { colorConfig, } = useSelector((state: RootState) => state.userInfo);
    const [salaryData, setSalaryData] = useState<any>(null);
    const [loading, setLoading] = useState(false);
    const [rceId, setRceIde] = useState('')
    const getMonthName = (month: number) => {
        const months = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        return months[month - 1];
    };

    // API call
    const fetchSalary = async (month: number, year: number) => {
        try {
            setLoading(true);
            const response = await post(
                { url: `${APP_URLS.RCETotalSalary}?Month=${month}&Year=${year}` }
            );

            const data = response?.Content?.ADDINFO?.[0];
            if (data) {
                setSalaryData(data);
                setRceIde(data.ceid)
            }
        } catch (error) {
            console.log("RCE salary API error:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchSalary(12, 2025); // DEC 2025
    }, []);

    // const fetchDetialSalary = async (month: number, year: number) => {
    //     try {
    //         const response = await post(
    //             { url: `${APP_URLS.RCETotalSalary}?RCEID=${rceId}&Month=${month}&Year=${year}` }
    //         );
    //         const data = response?.Content?.ADDINFO?.[0]
    //         if (data) {
    //             setSalaryData(data);
    //         }
    //     } catch (error) {

    //     }
    // }
    //     useEffect(() => {
    //     fetchDetialSalary(12, 2025); // DEC 2025
    // }, []);
    return (
        <SafeAreaView style={styles.container}>
            <AppBarSecond title={'RCE Payout Information'} />

            <View style={[styles.monthRow, { backgroundColor: `${colorConfig.secondaryColor}33` }]}>
                <View style={[styles.monthBox, styles.activeBorder, { borderColor: colorConfig.primaryColor }]}>
                    <CalendarCmssvg
                        month={getMonthName(salaryData.SalaryMonth)
                            .slice(0, 3)
                            .toUpperCase()}
                        year={salaryData.SalaryYear.toString()}
                    />
                    <View style={{}}>
                        <Text style={styles.monthValue}>{getMonthName(salaryData.SalaryMonth)} {salaryData.SalaryYear}
                        </Text>
                    </View>
                </View>

                <View style={[styles.monthBox, styles.activeBorder, { borderColor: colorConfig.primaryColor }]}>
                    <CalendarCmssvg
                        month={getMonthName(salaryData.SalaryMonth)
                            .slice(0, 3)
                            .toUpperCase()}
                        year={salaryData.SalaryYear.toString()}
                    />
                    <View style={{}}>
                        <Text style={styles.monthValue}>
                            {getMonthName(salaryData.SalaryMonth)} {salaryData.SalaryYear}
                        </Text>
                        {/* <Text style={styles.monthValue}>Your PayOut Info</Text> */}
                    </View>
                </View>

                <View style={styles.monthBox}>
                    <CalendarCmssvg
                        month={getMonthName(salaryData.SalaryMonth)
                            .slice(0, 3)
                            .toUpperCase()}
                        year={salaryData.SalaryYear.toString()}
                    />
                    <View>
                        <Text style={styles.monthValue}>
                            {getMonthName(salaryData.SalaryMonth)} {salaryData.SalaryYear}
                        </Text>
                    </View>
                </View>
            </View>

            <ScrollView contentContainerStyle={styles.content}>

                {/* Note */}
                <Text style={styles.note}>
                    Note:- All this information is available in the database. The total
                    amount has been calculated based on your payment collection and
                    attendance. If you have any questions or concerns, please contact the
                    accounts team immediately.
                </Text>
                <View
                    style={{
                        backgroundColor: "#ddd",
                        paddingHorizontal: wScale(10),
                        paddingBottom: hScale(20),
                        borderTopRightRadius: 8,
                        borderTopLeftRadius: 8,
                    }}
                >
                    {salaryData && (
                        <Text style={styles.sectionTitle}>
                            {getMonthName(salaryData.SalaryMonth)}{" "}
                            <Text style={{ color: "green" }}>
                                {salaryData.SalaryYear}
                            </Text>{" "}
                            Monthly Payout
                        </Text>
                    )}

                    {/* Table Header */}
                    <View style={styles.tableHeader}>
                        <Text style={styles.tableHeaderText}>Description</Text>
                        <Text style={styles.tableHeaderText}>Amount (₹)</Text>
                    </View>

                    {loading && (
                        <Text style={{ textAlign: "center", padding: 10 }}>
                            Loading...
                        </Text>
                    )}

                    {/* Table Rows */}
                    {salaryData && (
                        <>
                            <View style={styles.tableRow}>
                                <Text style={styles.tableCell}>Total Pickup Amount</Text>
                                <Text style={styles.tableCell}>
                                    ₹ {salaryData.TotalPickUpAmount}
                                </Text>
                            </View>

                            <View style={styles.tableRow}>
                                <Text style={styles.tableCell}>Final Minimum Pay</Text>
                                <Text style={styles.tableCell}>
                                    ₹ {salaryData.FinalMinPay}
                                </Text>
                            </View>

                            <View style={styles.tableRow}>
                                <Text style={styles.tableCell}>Total Commission</Text>
                                <Text style={styles.tableCell}>
                                    ₹ {salaryData.TotalFinalCommission}
                                </Text>
                            </View>

                            <View style={styles.tableRow}>
                                <Text style={styles.tableCell}>Travel Allowance</Text>
                                <Text style={styles.tableCell}>
                                    ₹ {salaryData.FinalTravels}
                                </Text>
                            </View>

                            <View style={styles.tableRow}>
                                <Text style={styles.tableCell}>Penalty</Text>
                                <Text style={styles.tableCell}>
                                    ₹ {salaryData.TotalPenlity}
                                </Text>
                            </View>

                            <View style={styles.tableRow}>
                                <Text style={styles.tableCell}>TDS</Text>
                                <Text style={styles.tableCell}>
                                    ₹ {salaryData.TDS}
                                </Text>
                            </View>

                            <View style={styles.tableRow}>
                                <Text
                                    style={[
                                        styles.tableCell,
                                        { fontWeight: "bold" },
                                    ]}
                                >
                                    Net Salary
                                </Text>
                                <Text
                                    style={[
                                        styles.tableCell,
                                        { fontWeight: "bold", color: "green" },
                                    ]}
                                >
                                    ₹ {salaryData.NetSalary}
                                </Text>
                            </View>
                        </>
                    )}
                </View>
            </ScrollView>
        </SafeAreaView>

    );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#f4f6f8",

    },

    header: {
        backgroundColor: "#4a6ee0",
        padding: 16,
        alignItems: "center",
    },

    headerTitle: {
        color: "#fff",
        fontSize: 18,
        fontWeight: "bold",
    },

    content: {
        paddingHorizontal: wScale(15),
        paddingVertical: hScale(10)
    },

    monthRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        backgroundColor: '#F4B5B5'
    },

    monthBox: {
        width: "33%",
        // backgroundColor: "#e8ebff",
        paddingHorizontal: wScale(5),
        alignItems: "center",
        // flexDirection: 'row',
        paddingVertical: 5,
        // justifyContent: 'space-between',


    },

    monthLabel: {
        fontSize: 12,
        color: "#555",
    },

    monthValue: {
        fontSize: 12,
        color: '#000'
    },

    note: {
        color: "red",
        fontSize: wScale(11),
        marginBottom: 12,
        textAlign: 'justify'
    },

    sectionTitle: {
        fontSize: 16,
        fontWeight: "bold",
        marginVertical: 10,
        textAlign: "center",
    },

    tableHeader: {
        flexDirection: "row",
        backgroundColor: "#1f2937",
        padding: 10,
    },

    tableHeaderText: {
        flex: 1,
        color: "#fff",
        fontWeight: "bold",
        textAlign: "center",
    },

    tableRow: {
        flexDirection: "row",
        backgroundColor: "#fff",
        borderBottomWidth: 1,
        borderColor: "#ddd",
    },

    tableCell: {
        flex: 1,
        padding: 14,
        // textAlign: "center",
        color: "#333",
    },

    bottomNav: {
        flexDirection: "row",
        justifyContent: "space-around",
        paddingVertical: 12,
        backgroundColor: "#fff",
        borderTopWidth: 1,
        borderColor: "#ddd",
    },

    navItem: {
        color: "#777",
    },

    navItemActive: {
        color: "#4a6ee0",
        fontWeight: "bold",
    },
    activeBorder: {
        borderBottomWidth: 1
    }
});
