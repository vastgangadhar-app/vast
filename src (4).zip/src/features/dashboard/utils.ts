export type sectionData = {
  name: string;
  svg: string;
  ScreenName: string;
};

export type BalanceType = {
  remainbal: number;
  posremain: number;
  totalCurrentcr: number;
  admincr: number;
  dealer: number;
  tholdamount: number;
  frmanems:''
};
