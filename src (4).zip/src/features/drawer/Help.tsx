import React from 'react';
import {View, Text} from 'react-native';
import AppBar from './headerAppbar/AppBar';
import HelpAndSupport from './help&support/helpandsupport';

const Help_And = () => {
  return (
    <View>
      <HelpAndSupport />
    </View>
  );
};
export default Help_And;
