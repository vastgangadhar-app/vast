import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking, Image } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { hScale, wScale } from '../../../utils/styles/dimensions';
import useAxiosHook from '../../../utils/network/AxiosClient';
import { APP_URLS } from '../../../utils/network/urls';
import DeviceInfo from 'react-native-device-info';
import UpdateSvg from '../../drawer/svgimgcomponents/UpdateSvg';
import { useSelector } from 'react-redux';
import { RootState } from '../../../reduxUtils/store';
import DynamicButton from '../../drawer/button/DynamicButton';

const UpdateScreen = ({ isPlay }) => {
  const { colorConfig, } = useSelector((state: RootState) => state.userInfo);

  const { get } = useAxiosHook();
  const [latestVersion, setLatestVersion] = useState('');
  const [currentVersion, setCurrentVersion] = useState('');

  useEffect(() => {
    const fetchVersion = async () => {
      try {
        const version = await get({ url: APP_URLS.current_version });
        setLatestVersion(version.currentversion);
        setCurrentVersion(APP_URLS.version);
      } catch (error) {
        console.error('Version fetch error:', error);
      }
    };
    fetchVersion();
  }, []);

  const handleUpdate = () => {
    const url = isPlay
      ? APP_URLS.playUrl
      : `https://${APP_URLS.baseWebUrl}/Home/DownloadAPK`;
    Linking.openURL(url).catch(err => console.error('URL open failed:', err));
  };

  return (
    <LinearGradient
      colors={[colorConfig.primaryColor, colorConfig.secondaryColor]}
      style={styles.container}
    >
      <View style={styles.content}>

        <View style={{ backgroundColor: '#fff', borderRadius: 100, padding: wScale(30) }}>
          <UpdateSvg color2={colorConfig.primaryColor} color={colorConfig.secondaryColor} />

        </View>
        <Text style={styles.title}>
          New Update Required
        </Text>

        {/* Version Info */}
        <View style={styles.versionBox}>
          <Text style={styles.availableText}>
            Now Available Version is : <Text style={styles.versionValue}>V{latestVersion}</Text>
          </Text>
        </View>

        <Text style={styles.prevText}>
          Your Previously Installed Version : V{currentVersion}
        </Text>

        {/* What's New Section */}
        <View style={styles.updateBox}>
          <Text style={styles.updateTitle}>What's improved in this update?</Text>

          <View style={styles.bulletContainer}>
            {[
              'Fixed minor bugs and crashes',
              'Improved performance and speed',
              'Enhanced design and usability',
              'Security updates for better protection',
            ].map((item, index) => (
              <View key={index} style={styles.bulletItem}>
                <Text style={styles.bulletSymbol}>•</Text>
                <Text style={styles.bulletText}>{item}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Update Button */}
        {/* <TouchableOpacity onPress={handleUpdate} style={styles.button}>
          <Text style={styles.buttonText}>
            Update Now
          </Text>
        </TouchableOpacity> */}
      </View>
      <View style={{ width: '90%', alignSelf: 'center', marginBottom: hScale(30) }}>
        <DynamicButton title={'Download & Update Now'}
          onPress={handleUpdate} />
        <Text style={styles.note}>
          If the update doesn’t start, please uninstall and reinstall the app manually.
        </Text>
      </View>

    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    width: '90%',
    paddingTop: hScale(40),
    alignSelf: 'center'
  },
  icon: {
    width: wScale(150),
    height: hScale(150),
    marginBottom: hScale(20),
  },
  title: {
    fontSize: wScale(32),
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: hScale(10),
  },
  highlight: {
    color: '#1B5E20',
  },
  versionBox: {
    backgroundColor: '#E8F5E9',
    borderRadius: wScale(20),
    paddingVertical: hScale(6),
    paddingHorizontal: wScale(15),
    marginBottom: hScale(6),
  },
  availableText: {
    fontSize: wScale(16),
    color: '#388E3C',
    fontWeight: '600',
  },
  versionValue: {
    fontWeight: 'bold',
  },
  prevText: {
    fontSize: wScale(15),
    color: '#fff',
    marginBottom: hScale(20),
  },
  updateBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    width: '100%',
    borderRadius: wScale(15),
    paddingVertical: hScale(15),
    paddingHorizontal: wScale(15),
    marginBottom: hScale(25),
  },
  updateTitle: {
    fontSize: wScale(16),
    fontWeight: '600',
    color: '#000',
    marginBottom: hScale(10),
  },
  bulletContainer: {
    marginLeft: wScale(5),
  },
  bulletItem: {
    flexDirection: 'row',
    marginBottom: hScale(5),
  },
  bulletSymbol: {
    fontSize: wScale(16),
    color: '#2196F3',
    marginRight: wScale(6),
  },
  bulletText: {
    color: '#444',
    fontSize: wScale(14),
    flex: 1,
  },
  note: {
    color: '#fff',
    fontSize: wScale(14),
    marginTop:hScale(10)
  },
  button: {
    backgroundColor: '#2196F3',
    borderRadius: wScale(30),
    paddingVertical: hScale(12),
    paddingHorizontal: wScale(50),
    elevation: 4,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: wScale(16),
  },
});

export default UpdateScreen;
