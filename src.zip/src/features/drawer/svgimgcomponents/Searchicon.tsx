import React from "react";
import { View, Text } from "react-native";
import { SvgXml } from "react-native-svg";
import { wScale } from "../../../utils/styles/dimensions";

const SearchIcon = ({ size = wScale(25), color = "#fff" }) => {
    const searchicon = `

<?xml version="1.0" encoding="iso-8859-1"?>
<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 480.606 480.606" style="enable-background:new 0 0 480.606 480.606;" xml:space="preserve">
<path d="M480.606,459.394L352.832,331.619c30.306-35.168,48.654-80.918,48.654-130.876C401.485,90.053,311.433,0,200.743,0
	S0,90.053,0,200.743s90.053,200.743,200.743,200.743c49.958,0,95.708-18.348,130.876-48.654l127.775,127.775L480.606,459.394z
	 M30,200.743C30,106.595,106.595,30,200.743,30s170.743,76.595,170.743,170.743s-76.595,170.743-170.743,170.743
	S30,294.891,30,200.743z" fill="${color}"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>

 `
    return (
        <View>
            <SvgXml xml={searchicon} width={size} height={size} />
        </View>
    );
};


export default SearchIcon;