import React from 'react';

const LayoutContext = React.createContext<any>({
  buttonHeight: 0,
});

export default LayoutContext;