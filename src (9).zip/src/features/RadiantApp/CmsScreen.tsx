import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSelector } from 'react-redux';

import RadiantTransactionScreen from './RadiantTransactionScreen';
import Pendingcms from './RadiantNewClient/Pendingcms';
import InterestVerification from './RadiantNewClient/InterestVerification';
import RadiantStep from './Radiantregister/RadiantStep';
import RadiantWellCome from './RadiantNewClient/RadiantWellCome';
import CheckPendingForm from './RadiantNewClient/CheckPendingForm';
import DownloadDocRadiant from './Radiantregister/DownloadDocRadiant';

import useAxiosHook from '../../utils/network/AxiosClient';
import { APP_URLS } from '../../utils/network/urls';
import { RootState } from '../../reduxUtils/store';
import { log } from 'console';
import { useDispatch } from 'react-redux';
import { setRctype } from '../../reduxUtils/store/userInfoSlice';
import AddMoneyPayResponse from '../../components/AddMoneyPayResponse';
import CmsPrePayFinalVfy from './RadiantTrxn/CmsPrePayFinalVfy';
import CashPickupTestScreen from './CashPickupTestScreen';

const CmsScreen = () => {
  const { rceIdStatus } = useSelector((state: RootState) => state.userInfo);

  const [status, setStatus] = useState<boolean | null>(null);
  const [status2, setStatus2] = useState<string>('');
  const [checkInfo, setCheckInfo] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [type, setType] = useState(null);

  const { post } = useAxiosHook();
  const dispatch = useDispatch()
  useEffect(() => {
    const loadStatus = async () => {
      setLoading(true);

      try {

        const res1 = await post({ url: APP_URLS.RCEID });
        const s1 = res1?.Content?.ADDINFO?.sts ?? null;
        setStatus(s1);
        const t1 = res1?.Content?.ADDINFO?.Type ?? null;
        setType(t1);
        dispatch(setRctype(t1));
        console.log("STATUS:", s1);
        console.log("FULL RESPONSE:\n", JSON.stringify(res1, null, 2));
        console.log("-------------------------------");
        // -------------------------------
        // STEP 2: If status === false → Second API
        // -------------------------------
        if (s1 === false) {
          const res2 = await post({ url: APP_URLS.RadiantCEIntersetCheck });
          const s2 = res2?.Content?.ADDINFO?.sts ?? '';
          setStatus2(s2);

          // -------------------------------
          // STEP 3: If status2 = DocVerification / Success → Third API
          // -------------------------------
          if (s2 === 'DocVerification' || s2 === 'Success') {
            const res3 = await post({ url: APP_URLS.CheckPendingForm });
            setCheckInfo(res3?.status ?? '');
          }
        }

        // -------------------------------
        // Read Local Storage as fallback
        // -------------------------------
        const localData = await AsyncStorage.getItem('adminFarmData');
        if (localData) {
          const parsed = JSON.parse(localData);
          if (!status2) setStatus2(parsed.status2 || '');
        }
      } catch (error) {
        console.error('Error:', error);
      }

      setLoading(false);
    };

    loadStatus();
  }, []);

  // -----------------------------------------------------
  // LOADING → Always show Welcome Screen
  // -----------------------------------------------------
  if (loading || status === null) {
    return <RadiantWellCome />;
  }

  // -----------------------------------------------------
  // RENDERING LOGIC
  // -----------------------------------------------------
  const renderScreen = () => {
    if (status === true) {
      return <RadiantTransactionScreen />;
    }

    if (status === false) {
      switch (status2) {
        case 'Pending':
        case 'DocPending':
        case 'CERegPending':
        case 'CEPointsPending':
          return <Pendingcms />;

        case 'Success':
        case 'DocVerification':
          if (checkInfo === 'Pending') return <CheckPendingForm />;
          if (checkInfo === 'Approved') return <DownloadDocRadiant />;
          return <RadiantStep />;

        case 'DocSuccess':
          return <RadiantTransactionScreen />;

        case 'New':
        case 'Failed':
        default:
          return <InterestVerification />;
      }
    }

    return <RadiantWellCome />;
  };

  return (
    <View style={styles.container}>
      {renderScreen()}
      {/* <AddMoneyPayResponse /> */}

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#f5f5f5',
  },
});

export default CmsScreen;
