import React from "react";
import { View,Text } from "react-native";

const Privacy = () => {
    return (
        <View>
            <Text>Privacy Policy Page</Text>

        </View>

    );
}
export default Privacy;