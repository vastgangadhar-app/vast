import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, useColorScheme, Alert } from 'react-native';
import { APP_URLS } from '../../../utils/network/urls';
import useAxiosHook from '../../../utils/network/AxiosClient';
import {
  getDeviceInfo,
  captureFinger,
} from 'react-native-rdservice-fingerprintscanner';
import AepsTabScreen from './AepsTabScreen';
import { hScale, SCREEN_WIDTH, wScale } from '../../../utils/styles/dimensions';
import { useSelector } from 'react-redux';
import { RootState } from '../../../reduxUtils/store';

import AppBarSecond from '../../drawer/headerAppbar/AppBarSecond';
import CheckSvg from '../../drawer/svgimgcomponents/CheckSvg';
import { useDispatch } from 'react-redux';
import { setActiveAepsLine } from '../../../reduxUtils/store/userInfoSlice';
const AepsScreen = () => {
  const { colorConfig } = useSelector((state: RootState) => state.userInfo);
  const color1 = `${colorConfig.primaryColor}20`;
  const navigation = useNavigation<any>();
  const colorScheme = useColorScheme();
  const [fingerprintData, setFingerprintData] = useState<any>();
  const [currentRoute, setCurrentRoute] = useState('');
  const buttonTextColor = colorScheme === 'dark' ? 'white' : 'black';
  const { get, post } = useAxiosHook();
  const [isSuccess, setIsSucess] = useState(false);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(); // 1 or 2
  const [statusFlags, setStatusFlags] = useState({ status1: null, status2: null });

  // useEffect(() => {
  //   CheckAeps();
  // }, []);
  const dispatch = useDispatch();
  const CheckAeps = async (requestedLine) => {
    try {
      const url = `${APP_URLS.AepsStatusCheck}`;
      const response = await post({ url });
      const { status1, status2 } = response;
      setStatusFlags({ status1, status2 });

      if (requestedLine === 1) {
        if (status1 === true) {
          setSelected(1);
          dispatch(setActiveAepsLine(true)); // ✅ Set green in Redux
        } else {
          Alert.alert(
            'Service Notice',
            'This bank’s API is currently closed. Please try Yellow Line AEPS.'
          );
        }
      } else if (requestedLine === 2) {
        if (status2 === true) {
          setSelected(2);
          dispatch(setActiveAepsLine(false)); // ✅ Set green in Redux

        } else {
          Alert.alert(
            'Service Notice',
            'This bank’s API is currently closed. Please try Green Line AEPS.'
          );
        }
      }

      if (status1 === false && status2 === false) {
        Alert.alert(
          'Service Notice',
          'Both AEPS services are currently unavailable. Please try again later.'
        );
        setSelected(undefined);
      }

    } catch (error) {
      console.log('❌ API Error:', error);
    }
  };



  const start = () => {
    getDeviceInfo()
      .then((res) => {
        capture();
      })
      .catch((e) => {
        Alert.alert('Error While Scanning the finger. Please check if device is connected properly');
      });
  }; const start2 = () => {
    getDeviceInfo()
      .then((res) => {
        capture2();
      })
      .catch((e) => {
        Alert.alert('Error While Scanning the finger. Please check if device is connected properly');
      });
  };

  const capture = () => {

    captureFinger('<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" wadh="E0jzJ/P8UopUHAieZn8CKqS4WPMi5ZSYXgfnlfkWjrc=" posh="UNKNOWN" env="P" /> <CustOpts><Param name="mantrakey" value="" /></CustOpts> </PidOptions>') //you can pass pidOptions to "captureFinger(pidOptions)"" method otherwise it takes DEFAULT_PID_OPTIONS
      .then((res) => {
        setFingerprintData(res.pidDataJson);
        if (currentRoute) {
          navigation.navigate(currentRoute, { fingerprintData: res.pidDataJson });
        }
      })
      .catch((e) => {
        setFingerprintData('')
        Alert.alert('Error While Scanning the finger. Please check if device is connected.');
      });
  };
  const capture2 = () => {

    captureFinger('<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" wadh="E0jzJ/P8UopUHAieZn8CKqS4WPMi5ZSYXgfnlfkWjrc=" posh="UNKNOWN" env="P" /> <CustOpts><Param name="mantrakey" value="" /></CustOpts> </PidOptions>') //you can pass pidOptions to "captureFinger(pidOptions)"" method otherwise it takes DEFAULT_PID_OPTIONS
      .then((res) => {
        setFingerprintData(res.pidDataJson);
        navigation.navigate('Aepsekycscan', { fingerprintData: res.pidDataJson });

      })
      .catch((e) => {
        setFingerprintData('')
        Alert.alert('Error While Scanning the finger. Please check if device is connected.');
      });
  };


  return (
    <View style={styles.container}>
      <AppBarSecond
        title="AEPS / AADHAAR PAY"
        actionButton={undefined}
        onActionPress={undefined}
        onPressBack={undefined}
      />


      <View style={styles.row}>
        <TouchableOpacity
          style={[
            styles.button,
            selected === 1 && styles.selectedButton,
            { borderTopLeftRadius: 8, borderBottomLeftRadius: 8, backgroundColor: 'green', }
          ]}
          onPress={() => {
            // setSelected(1);
            CheckAeps(1);

            if (statusFlags.status1 === false) {
              Alert.alert(
                'Service Notice',
                'This bank’s API is currently closed. Please try Yellow Line AEPS.'
              );
            }
          }}
        >
          <View style={styles.check}>
            {selected === 1 && <CheckSvg color='green' size={17} />}
          </View>
          <Text style={styles.buttonText}>Green Line AEPS</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.button,
            selected === 2 && styles.selectedButton,
            { backgroundColor: '#e8de80', borderTopRightRadius: 8, borderBottomRightRadius: 8 }
          ]}
          onPress={() => {
            // setSelected(2);
            CheckAeps(2);


            if (statusFlags.status2 === false) {
              Alert.alert(
                'Service Notice',
                'This bank’s API is currently closed. Please try Green Line AEPS.'
              );
            }
          }}
        >
          <View style={styles.check}>
            {selected === 2 && <CheckSvg color='#e8de80' size={17} />}
          </View>
          <Text style={styles.buttonText}>Yellow Line AEPS</Text>
        </TouchableOpacity>
      </View>

      {selected === 1 && <AepsTabScreen  />}
      {selected === 2 && <AepsTabScreen />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: hScale(7),
    paddingHorizontal: wScale(5),
    marginTop: hScale(8)
  },
  button: {
    paddingVertical: hScale(5),
    paddingHorizontal: wScale(25),
    backgroundColor: '#ccc',
    flex: 1,
    alignItems: 'center',
    flexDirection: 'row',

  },
  selectedButton: {
    backgroundColor: '#4CAF50',
  },
  buttonText: {
    fontSize: wScale(16),
    color: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    fontWeight: 'bold',
    textTransform: 'uppercase'
  },
  check: {
    height: hScale(18),
    width: hScale(18),
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: wScale(8),

  }

});


export default AepsScreen;
