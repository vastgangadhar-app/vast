import React, { useEffect } from 'react';
import { ScrollView, View, Text, StyleSheet, Linking } from 'react-native';
import AppBarSecond from '../../drawer/headerAppbar/AppBarSecond';
import { hScale, wScale } from '../../../utils/styles/dimensions';
import { Button } from 'react-native-paper';
import BackSvg from '../../drawer/svgimgcomponents/BackSvg';
import { useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { RootState } from '../../../reduxUtils/store';
import DynamicButton from '../../drawer/button/DynamicButton';
import { APP_URLS } from '../../../utils/network/urls';
import { log } from 'console';
import useAxiosHook from '../../../utils/network/AxiosClient';

const CmsPayoutStructure = () => {
    const { colorConfig, userId } = useSelector((state: RootState) => state.userInfo);

    const navigation = useNavigation<any>();

    const handleWebsiteLink = () => {

        Linking.openURL('https://www.radiantcashservices.com/');
    };


    const handleGoBack = () => {
        navigation.goBack()
    };
   const { post } = useAxiosHook();  // Assuming this hook provides a post function

const fetchData = async () => {
    try {
        // Define the URL
        const url = APP_URLS.RCEPayoutStructure;

        // Print the URL to the console for debugging
        console.log('Fetching data from URL:', url);

        // Perform the POST request using your custom hook
        const response = await post({url});

        // Log the entire response for debugging
        console.log('Full Response:', response);

        // Check if the response has the data key
        if (response && response.data) {
            console.log('Response data:', response.data);
        } else {
            throw new Error('No data received in response');
        }

    } catch (error) {
        // Log full error details for debugging
        console.error('Error fetching data:', error);

        if (error.response) {
            // Log the complete error response for debugging
            console.error('Error response:', error.response);
            console.error('Error status:', error.response.status);
            console.error('Error message:', error.response.statusText);
        } else {
            // Log other errors like network issues
            console.error('Error message:', error.message);
        }
    }
};

useEffect(() => {
    fetchData();  // Fetch the data when the component mounts
}, []);

    return (
        <View style={styles.main}>
            <AppBarSecond title={'Payout Structure'} />
            <ScrollView style={styles.container}>
                <View style={styles.subtitleRow}>
                    <Text style={[styles.subtitle, { color: '#000' }]}>for retail cash executive</Text>
                    <Text style={styles.subtitle}>
                        Effective date: {new Date().toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                        })}
                    </Text>
                </View>

                <View style={styles.table}>
                    <TableRow heading values={['Particular', 'Wallet Model', 'Online Depos', 'Cash Depos']} />
                    <Text style={styles.sectionTitle}>RCE Minimum Fixed Payout</Text>
                    <TableRow values={['Primary Point Minimum Payout', '3500.00', '3000.00', '2500.00']} />
                    <TableRow values={['Secondary Point Minimum Payout', '800.00', '700.00', '600.00']} />
                    <TableRow values={['Travel Allowance Per KM', '', '3.00', '']} />
                    <TableRow values={['Monthly Max Travel Allowance Limit', '', '1500.00', '']} />
                </View>

                {/* Section: RCE Commission Base Maximum Payout */}
                <Text style={[styles.sectionTitle, { backgroundColor: '#c9f7b2' }]}>
                    RCE Commission Base Maximum Payout
                </Text>
                <Text style={styles.note}>
                    This applies when the commission is higher than the minimum guaranteed amount. Here, you will receive either
                    the minimum guaranteed amount (if higher) or the commission (if higher). Please note that you will not receive both;
                    you will receive the higher amount.
                </Text>
                <View style={styles.table}>
                    <TableRow
                        values={[
                            'Day Collection & Cash deposit',
                            'Not Allow',
                            '',
                            <Text>
                                1.00 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>
                        ]}
                    />

                    <TableRow
                        values={[
                            'Evening Collection & Cash deposit',
                            'Not Allow',
                            '',
                            <Text>
                                1.03 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>
                        ]}
                    />

                    <TableRow
                        values={[
                            'Day Collection & Online / Wallet',
                            <Text>
                                1.15 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>,
                            '',
                            'Not Allow'
                        ]}
                    />

                    <TableRow
                        values={[
                            'Evening Collection & Online / Wallet',
                            <Text>
                                1.18 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>,
                            '',
                            'Not Allow'
                        ]}
                    />

                    <TableRow
                        values={[
                            'Vaulting & Cash deposit',
                            'Not Allow',
                            '',
                            <Text>
                                0.95 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>
                        ]}
                    />

                    <TableRow
                        values={[
                            'Vaulting & Online / Wallet T+0',
                            <Text>
                                1.03 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>,
                            '',
                            'Not Allow'
                        ]}
                    />

                    <TableRow
                        values={[
                            'Vaulting & Online / Wallet T+1',
                            <Text>
                                0.97 <Text style={[styles.per, { color: 'red' }]}>Per thousand</Text>
                            </Text>,
                            '',
                            'Not Allow'
                        ]}
                    />

                    <TableRow values={['Travel Allowance Per KM', '', '3.00', '']} />
                    <TableRow values={['Monthly Max Travel Allowance Limit', '', '1500.00', '']} />


                </View>

                {/* Section: Leave and Penalty */}
                <Text style={[styles.sectionTitle, { backgroundColor: '#f5d3dd' }]}>Leave and Penalty Provisions</Text>
                <View style={styles.table}>
                    <TableRow values={['26 JAN, 15 Aug, 2 OCT, Diwali, Holi', '', 'Allow', '']} />
                    <TableRow values={[<Text>
                        All Days Working <Text style={[styles.per,]}>Emergency Leave</Text>
                    </Text>, '01 Emergency Leave in Calendar Monthe',]} />
                    <TableRow values={[<Text>
                        Banking Days Working <Text style={[styles.per,]}>Leave</Text>
                    </Text>, 'Not Allow',]} />
                    <TableRow values={[<Text>
                        Holiday/Weekend Working <Text style={[styles.per,]}>Leave</Text>
                    </Text>, 'Not Allow']} />
                    <TableRow values={[<Text>
                        Extra Leave/Miss Pickup - <Text style={[styles.per,]}>Penalty</Text>
                    </Text>, <Text style={[styles.per,]}>150</Text>,
                    <Text style={[styles.per,]}>150</Text>,
                    <Text style={[styles.per,]}>100</Text>]} />
                </View>

                {/* Section: Verification Fees */}
                <Text style={[styles.sectionTitle, { backgroundColor: '#fa5585' }]}>Verification Fees/Charges</Text>
                <Text style={styles.note}>
                    Please note that this fee will be deducted from the first payment made to the Retail Cash Executive.
                    This is a one-time fee and will not be deducted repeatedly. This is solely for the Retail Cash Executive's physical and
                    court record verification fee.
                </Text>
                <View style={styles.table}>
                    <TableRow values={['With Police Verification', '399', '399', '399']} />
                    <TableRow values={['Without Police Verification', '519', '519', '519']} />
                </View>

                <View style={{ paddingHorizontal: wScale(10), paddingTop: hScale(10) }}>
                    <DynamicButton
                        title={'Next'}
                        onPress={() => { navigation.navigate('CmsNewPin', { pay: 'pay' }); }}
                    />
                </View>

                <View style={styles.linksContainer}>
                    <Button
                        mode="text"
                        onPress={handleGoBack}
                        icon={() => <BackSvg size={15} color={colorConfig.primaryColor} />}
                    >
                        <Text style={[styles.goBackText, { color: colorConfig.primaryColor, }]}>{'Go Back'}</Text>
                    </Button>

                    <Button
                        mode="text"
                        onPress={handleWebsiteLink}
                    >
                        <Text style={[styles.websiteLinkText, { color: colorConfig.secondaryColor, textDecorationColor: colorConfig.secondaryColor }]}>Company Website Link</Text>
                    </Button>
                </View>
            </ScrollView >
        </View >
    );
};

const TableRow = ({ heading, values }) => {
    const visibleColumns = values.slice(1).filter(val => {
        if (typeof val === 'string') {
            return val.trim() !== '';
        }
        return true; // JSX element or non-string — assume visible
    }).length;

    const remainingWidth = 70;
    const dynamicColWidth = visibleColumns > 0 ? `${remainingWidth / visibleColumns}%` : '0%';

    return (
        <View style={[styles.row, heading && styles.headerRow]}>
            {values.map((value, index) => {
                const isFirst = index === 0;
                const isEmpty = typeof value === 'string' ? value.trim() === '' : false;

                // First column: fixed width
                if (isFirst) {
                    return (
                        <Text
                            key={index}
                            style={[
                                styles.cell,
                                styles.firstCell,
                                styles.cellBorder,
                                heading ? styles.headerCell : styles.bodyCell,
                            ]}
                        >
                            {value}
                        </Text>
                    );
                }

                // Remaining columns: hidden if empty string, otherwise dynamic width
                if (isEmpty) return null;

                return (
                    <Text
                        key={index}
                        style={[
                            styles.cell,
                            { width: dynamicColWidth },
                            styles.cellBorder,
                            heading ? styles.headerCell : styles.bodyCell,
                            styles.otherCell,
                        ]}
                    >
                        {value}
                    </Text>
                );
            })}
        </View>
    );
};


const styles = StyleSheet.create({
    main: {
        flex: 1,
    },
    container: {
        backgroundColor: '#fff',
    },
    subtitleRow: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    subtitle: {
        fontSize: wScale(14),
        color: 'red',
        textAlign: 'center',
        fontWeight: 'bold',
        textTransform: 'capitalize'
    },
    sectionTitle: {
        fontSize: wScale(15),
        fontWeight: 'bold',
        backgroundColor: '#f7e6b5',
        color: '#000',
        textAlign: 'center',
        letterSpacing: wScale(2),
    },
    note: {
        fontSize: wScale(10),
        color: 'red',
        paddingHorizontal: wScale(5),
        marginBottom: hScale(5),
        textAlign: 'left',
    },
    table: {
        marginTop: hScale(5),
        borderLeftWidth: wScale(0.5),
        borderColor: '#000',
    },
    row: {
        flexDirection: 'row',
        borderBottomWidth: wScale(0.5),
        borderColor: '#000',
        alignItems: 'center',

    },
    headerRow: {
        backgroundColor: '#000',
    },
    cell: {
        textAlign: 'center',
        paddingHorizontal: wScale(4),
        borderColor: '#000',
    },
    headerCell: {
        color: '#fff',
        fontWeight: 'bold',
        borderColor: '#fff',
        borderRightWidth: wScale(.5),

    },
    bodyCell: {
        fontSize: wScale(13),
        color: '#000',
    },
    firstCell: {
        width: '30%',
        textAlign: 'left',
        paddingHorizontal: wScale(5),
        fontWeight: 'bold',
        borderRightWidth: wScale(.5),
        borderColor: '#000'
    },
    otherCell: {
        textAlign: 'center',

    },
    cellBorder: {
        borderRightWidth: wScale(0.3),
        borderColor: '#000',
        padding: 0,
        height: '100%'
    },
    per: {
        color: 'red'
    },
    linksContainer: {
        marginTop: hScale(5),
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: hScale(20)
    },
    goBackText: {
        color: 'blue',
        fontSize: wScale(16),
    },
    websiteLinkText: {
        color: 'blue',
        fontSize: wScale(16),
        textDecorationLine: 'underline',
    },
});

export default CmsPayoutStructure;
