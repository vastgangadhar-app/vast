import React, { useCallback, useState } from "react";
import { View, Text, Button, ScrollView } from "react-native";
import uuid from "react-native-uuid";

const CashPickupTestScreen = () => {
  const [requestJson, setRequestJson] = useState(null);

  const submitWithDummyData = useCallback(async () => {
    // 🔸 DUMMY DATA
    const Loc_Data = { latitude: "28.6139", longitude: "77.2090" };
    const pickuptype = "Offline"; // change to "Online"
    const newId = uuid.v4();

    const dummyTransaction = {
        CType: "R",
      Uniqueid: newId
      requestType: "cashPickupTransSubmit",
      type: "Pickup",
      ceId: "CE123",
      shopId: "SHOP001",
      transId: "TRANS001",
      noRecs: 2,
      transParam: [
        { denom: 500, qty: 10 },
        { denom: 200, qty: 5 }
      ],
      depType: "CASH",
      qrTransId: "",
      latitude: Loc_Data.latitude,
      longitude: Loc_Data.longitude,
      pickuptype: pickuptype,
      Modelnumber: "TEST-MODEL",
      CType: "R",
      Uniqueid: newId
    };

    console.log("🧪 GENERATED REQUEST:", dummyTransaction);
    setRequestJson(dummyTransaction);

    // 🔴 API CALL YAHAN COMMENT RAKHO
    // await submitCashPickupTransaction(dummyTransaction);

  }, []);

  return (
    <ScrollView style={{ padding: 16 }}>
      <Button title="Submit Dummy Cash Pickup" onPress={submitWithDummyData} />

      {requestJson && (
        <>
          <Text style={{ marginTop: 20, fontWeight: "bold" }}>
            Generated Request:
          </Text>
          <Text>{JSON.stringify(requestJson, null, 2)}</Text>
        </>
      )}
    </ScrollView>
  );
};

export default CashPickupTestScreen;
