import React, { useEffect, useState ,useCallback} from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, PermissionsAndroid, Linking } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { hScale, wScale } from '../../../utils/styles/dimensions';
import { FlashList } from '@shopify/flash-list';
import { FontSize } from '../../../utils/styles/theme';
import { useNavigation } from '@react-navigation/native';
import RadintTransactSvg from '../../drawer/svgimgcomponents/RadintTransactSvg';
import useAxiosHook from '../../../utils/network/AxiosClient';
import useRadiantHook from '../../Financial/hook/useRadiantHook';
import { useLocationHook } from '../../../utils/hooks/useLocationHook';
import { check, openSettings, PERMISSIONS, RESULTS } from 'react-native-permissions';
import QRCodeScanner from 'react-native-qrcode-scanner';
import { ALERT_TYPE, Dialog } from 'react-native-alert-notification';

const CashPickup = () => {
  const navigation = useNavigation()
  // const { latitude, longitude, isLocationPermissionGranted, getLocation, checkLocationPermissionStatus, getLatLongValue } = useLocationHook();

  
  const {cashPickUpTransactionList, fetchCashPickupTransactionList, isLoading} = useRadiantHook();
  const [cashPickupList, setCashPickupList] = useState([]);
const {get, post} = useAxiosHook();
  const handleBack = () => {
   // requestCameraPermission()

    navigation.goBack();
  };


  async function requestLocationPermission() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'We need access to your location',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );

      console.log('===========================')
      console.log(granted);
      console.log('===========================')
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log('Location permission granted');
      } else {
        console.log('Location permission denied');
      }
    } catch (err) {
      console.warn(err);
    }
  }
  useEffect(() => {
    const fetchData = async () => {
      await fetchCashPickupTransactionList();
    //  await getLocation();
      setCashPickupList(cashPickUpTransactionList); 
      
      console.log(cashPickUpTransactionList);

      // console.log(isLocationPermissionGranted,longitude,latitude)
    }
    fetchData();
    return;
  },[])
  useEffect(() => {
    const fetchData2 = async () => {
    //  await getLocation();
    //  requestLocationPermission();
  //     check(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION)
  // .then((result) => {


  //   console.log(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION)
  //   switch (result) {
  //     case RESULTS.GRANTED:
  //       console.log('Location access is granted');
  //       break;
  //     case RESULTS.DENIED:
  //       console.log('Location access denied');
  //       break;
  //     case RESULTS.BLOCKED:
  //       console.log('Location access is blocked');
  //       break;
  //     case RESULTS.UNAVAILABLE:
  //       console.log('Location services are unavailable');
  //       break;
  //   }
  // })
  // .catch((error) => {
  //   console.log('Error checking permission:', error);
  // });

      // console.log(isLocationPermissionGranted,longitude,latitude)
    }
   // fetchData2();
    return;
  },[])

  const onSuccess = (e) => {
    console.log(e.data);
 //   setIsScan(false);

   // Linking.openURL(e.data).catch((err) => console.error('An error occurred', err));
  };
  const renderItem = ({ item }) => (

    <TouchableOpacity onPress={() => navigation.navigate('PicUpScreen', { item })}>

      <View style={styles.itemContainer}>
        <View style={styles.textContainer}>
          <Text style={styles.nameText}>{item.CustName}</Text>
          <Text style={styles.addressText}>{item?.PointName}</Text>

        </View>
        <View style={styles.detailContainer}>
          <Text style={styles.clientCodeText}>Client Code: {item?.ClientCode?.length}</Text>

          <View style={styles.pickupContainer}>
            <Text style={styles.pickupText}>{item.Type}</Text>
            <Text style={styles.pickupCount}>{item.ClientCode?.length}</Text>
            <Text style={styles.arrow}>{'>'}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
 
  const requestCameraPermission = useCallback(async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'Camera Permission',
          message: 'This app needs access to your camera to take photos and videos.',
          buttonPositive: 'OK',
        }
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {

setIsScan(true);
      } else {
        Dialog.show({
          type: ALERT_TYPE.WARNING,
          title: 'Permission Required',
          textBody: 'Please grant the camera permission from settings.',
          button: 'OK',
          onPressButton: () => {
            Dialog.hide();
            openSettings().catch(() => console.warn('Cannot open settings'));
          },
        });
      }
    } catch (err) {
      console.warn(err);
    }
  }, []);
  

  return (
    <View style={styles.main}>

 {/* <QRCodeScanner
  
      onRead={onSuccess}
      
    /> */}
      <Text style={styles.topappBar}>Radiant Sandesh</Text>

      <View style={styles.appBar}>

        <TouchableOpacity onPress={handleBack}>
          <RadintTransactSvg size={35} />
        </TouchableOpacity>

        <Text style={styles.appBarText}>Transactions</Text>
      </View>
      <View style={styles.container}>


        <View style={styles.contentContainer}>
          <Svg height="50" width="50">
            <Circle cx="25" cy="25" r="20" fill="#fff" />
          </Svg>
          <Text style={styles.cashPickupText}>{'Cash Pickup'.toUpperCase()}</Text>
        </View>
       {isLoading && <ActivityIndicator color={'#0000000'} size="large" style={{marginTop: wScale(50)}}  />}
        <FlashList
          data={cashPickUpTransactionList}
          renderItem={renderItem}
          estimatedItemSize={70}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  topappBar: {
    paddingVertical: hScale(10),
    backgroundColor: '#1e201d',
    paddingHorizontal: 16,
    color: '#fff',
    fontSize: wScale(20),
    fontWeight: 'bold',
  },
  appBar: {
    paddingVertical: hScale(10),
    backgroundColor: '#e45a55',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wScale(20),
  },
  appBarText: {
    color: '#fff',
    fontSize: wScale(20),
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  contentContainer: {
    height: hScale(70),
    backgroundColor: '#e45a55',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  cashPickupText: {
    marginLeft: 10,
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#3f423f',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  textContainer: {
    flex: 1
  },
  nameText: {
    color: '#fff',
    fontSize: FontSize.large,
    fontWeight: 'bold',
  },
  clientCodeText: {
    color: 'yellow',
    fontSize: 14,
  },
  detailContainer: {
    flex: 1,
    alignItems: 'flex-end',
  },
  addressText: {
    color: '#d3d3d3',
    fontSize: FontSize.teeny

  },
  pickupContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start'
  },
  pickupText: {
    color: '#d3d3d3',
    fontSize: 14,
    paddingRight: wScale(50),
    paddingLeft: wScale(10)
  },
  pickupCount: {
    color: 'yellow',
    fontSize: 20,
    marginRight: 5,
  },
  arrow: {
    color: '#fff',
    fontSize: 30,
  },
});

export default CashPickup;

