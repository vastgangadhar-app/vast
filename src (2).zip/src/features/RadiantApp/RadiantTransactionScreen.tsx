import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { wScale, hScale } from '../../utils/styles/dimensions';
import RadintTransactSvg from '../drawer/svgimgcomponents/RadintTransactSvg';
import RadintEditSvg from '../drawer/svgimgcomponents/RadintEditSvg';
import RadintPickupSvg from '../drawer/svgimgcomponents/RadintPickupSvg';
import { colors } from '../../utils/styles/theme';
import RadintDepositSvg from '../drawer/svgimgcomponents/RadintDepositSvg';
import RadintChequeSvg from '../drawer/svgimgcomponents/RadintChequeSvg';
import RadintDeliverySvg from '../drawer/svgimgcomponents/RadintDeliverySvg';

const RadiantTransactionScreen = () => {
  const navigation = useNavigation();

  const transactions = [
    { id: '1', title: 'Cash Pickup', nav: 'CashPickup', img: <RadintPickupSvg /> },
    { id: '2', title: 'Cash Delivery', nav: 'CashDelivery', img: <RadintDeliverySvg /> },
    { id: '3', title: 'Cheque Pickup', nav: 'ChequePickup', img: <RadintChequeSvg /> },
    { id: '4', title: 'Deposit', nav: 'Deposit', img: <RadintDepositSvg /> },
  ];

  const handleTransactionPress = (item) => {
    navigation.navigate(item.nav);
  };

  const handleBack = () => {
    navigation.goBack();
  };

  const renderTransactionItem = ({ item }) => (
    <TouchableOpacity style={styles.card} activeOpacity={0.7} onPress={() => handleTransactionPress(item)}>
      {item.img}
      <Text style={styles.cardText}>{item.title}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.main}>

      <View style={styles.appBar}>
        <TouchableOpacity onPress={handleBack}>
          <RadintTransactSvg size={35} />
        </TouchableOpacity>
        <Text style={styles.appBarText}>Transactions</Text>
      </View>

      <View style={styles.container}>
        <FlatList
          data={transactions}
          renderItem={renderTransactionItem}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}

        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: wScale(0),
    backgroundColor: '#262626',
  },
  container: {
    flex: 1,
    paddingHorizontal: wScale(20),
    paddingTop: hScale(20)
  },
  appBar: {
    paddingVertical: hScale(10),
    backgroundColor: '#e45a55',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wScale(20),
  },
  appBarText: {
    color: '#fff',
    fontSize: wScale(20),
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    paddingVertical: hScale(10),
    paddingHorizontal: wScale(20),
    marginVertical: hScale(20),
    shadowColor: '#000',
    elevation: 5,
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    borderWidth: wScale(4),
    borderColor: colors.black_primary_blur
  },
  cardText: {
    fontSize: wScale(18),
    paddingLeft: wScale(15),
    fontWeight: '600',
    color: '#333',
  },
});

export default RadiantTransactionScreen;
