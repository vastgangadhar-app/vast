import React, { memo, useEffect, useState } from 'react';
import { AsyncStorage, Pressable, ScrollView, TouchableOpacity } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { View, Text, StyleSheet } from 'react-native';
import IconButtons from './components/IconButtons';
import { SvgXml } from 'react-native-svg';
import { hScale, wScale } from '../../utils/styles/dimensions';
import { useSelector } from 'react-redux';
import { RootState } from '../../reduxUtils/store';
import useAxiosHook from '../../utils/network/AxiosClient';
import { APP_URLS } from '../../utils/network/urls';
import { sectionData } from './utils';
import { useNavigation } from '../../utils/navigation/NavigationService';
import AppBar from '../drawer/headerAppbar/AppBar';
const EditIcon = `
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" viewBox="0 0 60 60" version="1.1"><!-- Generator: Sketch 51.3 (57544) - http://www.bohemiancoding.com/sketch --><title>001 - Accessibility</title><desc>Created with Sketch.</desc><defs/><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g id="001---Accessibility" fill="#fff" fill-rule="nonzero"><path d="M30,0 C13.4314575,-1.01453063e-15 2.02906125e-15,13.4314575 0,30 C-2.02906125e-15,46.5685425 13.4314575,60 30,60 C46.5685425,60 60,46.5685425 60,30 C59.981263,13.4392249 46.5607751,0.0187370435 30,0 Z M30,58 C14.536027,58 2,45.463973 2,30 C2,14.536027 14.536027,2 30,2 C45.463973,2 58,14.536027 58,30 C57.9823655,45.4566626 45.4566626,57.9823655 30,58 Z" id="Shape"/><path d="M30,4 C15.6405965,4 4,15.6405965 4,30 C4,44.3594035 15.6405965,56 30,56 C44.3594035,56 56,44.3594035 56,30 C55.983468,15.6474499 44.3525501,4.01653204 30,4 Z M30,54 C16.745166,54 6,43.254834 6,30 C6,16.745166 16.745166,6 30,6 C43.254834,6 54,16.745166 54,30 C53.9845705,43.2484376 43.2484376,53.9845705 30,54 Z" id="Shape"/><path d="M30,21 C33.3137085,21 36,18.3137085 36,15 C36,11.6862915 33.3137085,9 30,9 C26.6862915,9 24,11.6862915 24,15 C24.0033074,18.3123376 26.6876624,20.9966926 30,21 Z M30,11 C32.209139,11 34,12.790861 34,15 C34,17.209139 32.209139,19 30,19 C27.790861,19 26,17.209139 26,15 C26,12.790861 27.790861,11 30,11 Z" id="Shape"/><path d="M43.927,22.008 L43.911,22.008 L33.411,22.951 C33.053,22.9836667 32.6946667,23 32.336,23 L27.664,23 C27.306,23 26.9483333,22.984 26.591,22.952 L16.073,22.008 C14.4211163,21.8782131 12.9767869,23.1121163 12.847,24.764 C12.7172131,26.4158837 13.9511163,27.8602131 15.603,27.99 L24.09,28.76 C24.6049502,28.8065341 24.999513,29.2379517 25,29.755 L25,32.055 C25.0003524,32.5549913 24.9067272,33.0505945 24.724,33.516 L19.912,45.771 C19.2412502,47.2864694 19.9260306,49.0587502 21.4415,49.7295 C22.9569694,50.4002498 24.7292502,49.7154694 25.4,48.2 L29.986,36.987 L34.615,48.23 C35.3052861,49.7074001 37.0492941,50.3628403 38.5417645,49.7057727 C40.034235,49.0487051 40.7285204,47.319794 40.105,45.813 L35.276,33.513 C35.0937471,33.0481548 35.0001344,32.5532967 35,32.054 L35,29.754 C35.000487,29.2369517 35.3950498,28.8055341 35.91,28.759 L44.383,27.99 C46.0351598,27.864079 47.2724208,26.4226598 47.1464999,24.7705 C47.020579,23.1183402 45.5791598,21.8810791 43.927,22.007 L43.927,22.008 Z M44.216,26 L35.729,26.77 C34.181153,26.903227 32.994277,28.2014405 33,29.755 L33,32.055 C32.9996019,32.8055551 33.1403827,33.5494884 33.415,34.248 L38.261,46.587 C38.4965494,47.0865416 38.2825416,47.6824506 37.783,47.918 C37.2834584,48.1535494 36.6875494,47.9395416 36.452,47.44 L31.833,36.227 C31.5266513,35.4847868 30.8029508,35.0005712 30,35.0005712 C29.1970492,35.0005712 28.4733487,35.4847868 28.167,36.227 L23.561,47.41 C23.4177952,47.7503309 23.0987074,47.9840573 22.7310323,48.017937 C22.3633573,48.0518168 22.0069313,47.8803363 21.8039457,47.5719054 C21.6009602,47.2634745 21.5844493,46.8682879 21.761,46.544 L26.59,34.244 C26.8627455,33.5461569 27.001829,32.8032475 27,32.054 L27,29.754 C27.0067669,28.1996736 25.8196157,26.9002889 24.271,26.767 L15.77,26 C15.2177153,25.9610639 14.8015639,25.4817847 14.8405,24.9295 C14.8794361,24.3772153 15.3587153,23.9610639 15.911,24 L26.411,24.943 C26.827,24.9803333 27.244,24.999 27.662,24.999 L32.334,24.999 C32.752,24.999 33.169,24.9803333 33.585,24.943 L44.08,24 C44.344286,23.9790735 44.6059809,24.0645905 44.8069115,24.237541 C45.007842,24.4104915 45.1313571,24.6565431 45.15,24.921 C45.1717311,25.1885073 45.0850194,25.4535218 44.9093653,25.6564455 C44.7337112,25.8593693 44.4838602,25.9831676 44.216,26 Z" id="Shape"/></g></g></svg>

`;

const QuickAccessScreen = () => {
  const { colorConfig } = useSelector((state: RootState) => state.userInfo);
  const [rechargeSectionData, setRechargeSectionData] = useState<sectionData[]>(
    [],
  );
  const [financeSectionData, setFinanceSectionData] = useState<sectionData[]>(
    [],
  );
  const [otherSectionData, setOtherSectionData] = useState<sectionData[]>([]);
  const [travelSectionData, setTravelSectionData] = useState<sectionData[]>([]);
  const [sliderImages, setSliderImages] = useState<any[]>([]);
  const { post } = useAxiosHook();
  const navigation = useNavigation();
  const [savedItems, setSavedItems] = useState([]);
  const clearAllData = async () => {
    try {
      await AsyncStorage.clear();
      console.log('All data cleared from AsyncStorage');
      // Optionally, update your state or perform any other actions after clearing
      setSavedItems([]); // Clear saved items state
    } catch (error) {
      console.error('Error clearing AsyncStorage:', error);
    }
  };

  const getItem = async () => {
    try {
      const storedItems = await AsyncStorage.getItem('quickAccessItems');
      if (storedItems) {
        const parsedItems = JSON.parse(storedItems);
        setSavedItems(parsedItems);
        // Print the items to console
        console.log('Loaded Items from AsyncStorage:', parsedItems);
      }
    } catch (error) {
      console.error('Error loading saved items from AsyncStorage:', error);
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      const rechargeSectionResponse = await post({
        url: APP_URLS.getRechargeSectionImages,
      });
      setRechargeSectionData(rechargeSectionResponse || []);

      const financeSectionResponse = await post({
        url: APP_URLS.getFinanceSectionImages,
      });
      console.log(financeSectionData)
      setFinanceSectionData(financeSectionResponse || []);

      const otherSectionResponse = await post({
        url: APP_URLS.getOtherSectionImages,
      });
      setOtherSectionData(otherSectionResponse || []);
      const travelSectionResponse = await post({
        url: APP_URLS.getTravelSectionImages,
      });
      setTravelSectionData(travelSectionResponse || []);
    };

    fetchData();
    getItem();
    //clearAllData()
  }, []);

  return (
    <View
      style={styles.main}>
      <LinearGradient
        style={{ paddingBottom: wScale(10) }}
        colors={[colorConfig.primaryColor, colorConfig.secondaryColor]}>
        <AppBar title={"Your Quick Access"} />

        <ScrollView >
          <View style={styles.Container}>
            <SvgXml xml={EditIcon} width={wScale(100)} height={wScale(100)} style={{ alignSelf: 'center', marginBottom: hScale(20) }} />
            <View style={styles.headercontant}>
              <IconButtons isQuickAccess={true} buttonData={savedItems} />
            </View>
            <View style={styles.Headers2}>
              <View style={styles.QuickAcces}>
                <Text style={styles.hedertitletexr}>Recharge Pay Bill</Text>
              </View>

              <View style={styles.headercontant}>
                <IconButtons isQuickAccess={true} buttonData={rechargeSectionData} getItem={getItem} />
              </View>
            </View>
            <View style={styles.Headers2}>
              <View style={styles.QuickAcces}>
                <Text style={styles.hedertitletexr}>Financial Services</Text>
              </View>
              <View style={styles.headercontant}>
                <IconButtons isQuickAccess={true} buttonData={financeSectionData} getItem={getItem} />
              </View>
            </View>
            <View style={styles.Headers2}>
              <View style={styles.QuickAcces}>
                <Text style={styles.hedertitletexr}>Travel Hotel</Text>
              </View>
              <View style={styles.headercontant}>
                <IconButtons isQuickAccess={true} buttonData={travelSectionData} getItem={getItem} />
              </View>
            </View>
            <View style={styles.Headers2}>
              <View style={styles.QuickAcces}>
                <Text style={styles.hedertitletexr}>Other Section</Text>
              </View>
              <View style={styles.headercontant}>
                <IconButtons isQuickAccess={true} buttonData={otherSectionData} getItem={getItem} />
              </View>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1
  },
  Container: {
    paddingHorizontal: wScale(20),
    paddingBottom: hScale(50),
    paddingTop: hScale(20),
    flex: 1
  },
  Headers2: {
  },
  QuickAcces: {
  },
  hedertitletexr: {
    fontSize: wScale(20),
    color: '#fff',
  },
  headercontant: {
    paddingVertical: hScale(12),
    marginLeft: wScale(-5)
  },
});

export default memo(QuickAccessScreen);