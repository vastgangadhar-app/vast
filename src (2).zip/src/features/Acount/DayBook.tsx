import React, { useState, useEffect } from 'react';
import { View, Text, Button, FlatList, StyleSheet, TouchableOpacity, useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';
import useAxiosHook from '../../utils/network/AxiosClient';
import { APP_URLS } from '../../utils/network/urls';
import { wScale } from '../../utils/styles/dimensions';
import AppBarSecond from '../drawer/headerAppbar/AppBarSecond';
import LinearGradient from 'react-native-linear-gradient';
import Calendarsvg from '../drawer/svgimgcomponents/Calendarsvg';
import SearchIcon from '../drawer/svgimgcomponents/Searchicon';
import { useSelector } from 'react-redux';
import { RootState } from '../../reduxUtils/store';
import DateRangePicker from '../../components/DateRange';

const DayBookReport = () => {
  const { colorConfig } = useSelector((state: RootState) => state.userInfo)
  const [inforeport, setInforeport] = useState([]);
  const [open, setOpen] = useState(false);
  const navigation = useNavigation();
  const { get, post } = useAxiosHook();
  const colorScheme = useColorScheme(); // Get the current theme
  const [selectedDate, setSelectedDate] = useState({
    from: new Date().toISOString().split('T')[0],
    to: new Date().toISOString().split('T')[0],
  });
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  useEffect(() => {
    DayE(selectedDate.from, selectedDate.to, selectedStatus);
  }, []);

  const onDateChange = (date) => {
    setSelectedDate(date);
    setOpen(false);
  };

  const DayE = async (from, to, status) => {
    try {
      const formattedFrom = new Date(from).toISOString().split('T')[0];
      const formattedTo = new Date(to).toISOString().split('T')[0];
      const url = `${APP_URLS.dayErm}${formattedFrom}`;
      const response = await get({ url: url });
      console.log(response);
      if (response.Status === 'Failed') {
        setInforeport([]);
      } else {
        setInforeport(response.RESULT);

      }

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const dummyData = [
    { Type: 'Aeps', Amount: 0, TotalSuccess: 0, TotalPending: 0, TotalFailed: 0 },
    { Type: 'Recharge', Amount: 0, TotalSuccess: 0, TotalPending: 0, TotalFailed: 0 },
    { Type: 'Pancard', Amount: 0, TotalSuccess: 0, TotalPending: 0, TotalFailed: 0 },
    { Type: 'DMT', Amount: 0, TotalSuccess: 0, TotalPending: 0, TotalFailed: 0 },
    { Type: 'UPI', Amount: 0, TotalSuccess: 0, TotalPending: 0, TotalFailed: 0 },
  ];

  const isDarkTheme = colorScheme === 'dark';
  const styles = getStyles(isDarkTheme);

  return (
    <View style={styles.main}>
      <AppBarSecond title={'Day Book'} />
      <LinearGradient
        colors={[colorConfig.primaryColor, colorConfig.secondaryColor]}>


        <DateRangePicker
          onDateSelected={(from, to) => setSelectedDate({ from, to })}
          SearchPress={(from, to, status) => DayE(from, to, status)}
          status={selectedStatus}
          setStatus={setSelectedStatus}

        />
      </LinearGradient>
      <View style={styles.container}>



        <FlatList
          data={inforeport.length === 0 ? dummyData : inforeport}
          keyExtractor={(item) => item.Type}
          renderItem={({ item }) => (
            <View style={styles.reportItem}>
              <View style={styles.reportHeader}>
                <View style={styles.typeContainer}>
                  <Text style={styles.typeLabel}>Particular</Text>
                  <Text style={styles.type}>{item.Type}</Text>
                </View>
                <View style={styles.earnContainer}>
                  <Text style={styles.earnLabel}>Earn</Text>
                  <Text style={styles.earnAmount}>{`\u20B9 ${item.Amount}`}</Text>
                </View>
              </View>
              <View style={styles.reportFooter}>
                <View style={styles.footerItem}>
                  <Text style={styles.footerLabel}>Total Success</Text>
                  <Text style={styles.footerAmount}>{`\u20B9 ${item.TotalSuccess}`}</Text>
                </View>
                <View style={styles.footerItem}>
                  <Text style={styles.footerLabel}>Total Pending</Text>
                  <Text style={styles.footerAmount}>{`\u20B9 ${item.TotalPending}`}</Text>
                </View>
                <View style={styles.footerItem}>
                  <Text style={styles.footerLabel}>Total Failed</Text>
                  <Text style={styles.footerAmount}>{`\u20B9 ${item.TotalFailed}`}</Text>
                </View>
              </View>
            </View>
          )}
        />
      </View>
    </View>
  );
};

const getStyles = (isDarkTheme) => StyleSheet.create({
  main: {
    flex: 1,
    backgroundColor: isDarkTheme ? '#121212' : '#f0f0f0',
  },
  container: {
    padding: wScale(10),
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: wScale(10),
    borderRadius: 5,
  },
  datePickerButton: {
    paddingHorizontal: wScale(10),
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: wScale(1),
    borderColor: '#fff',

  },
  searchButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: wScale(15),
    backgroundColor: '#007bff',
    borderRadius: 5,
    borderColor: '#fff',
    borderWidth: wScale(1),

  },
  buttonText: {
    color: '#fff',
    fontSize: wScale(14),
  },


  title: {
    color: '#fff',
    fontSize: 20,
  },
  datePicker: {
    backgroundColor: '#03dac6',
    padding: 10,
    borderRadius: 5,
  },
  dateText: {
    color: '#fff',
    fontSize: 16,
  },
  loader: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 18,
  },
  reportItem: {
    backgroundColor: isDarkTheme ? '#1f1f1f' : '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  typeContainer: {
    flex: 1,
    marginLeft: 10,
  },
  typeLabel: {
    fontSize: 10,
    color: isDarkTheme ? '#fff' : '#000',
  },
  type: {
    fontSize: 14,
    fontWeight: 'bold',
    color: isDarkTheme ? '#fff' : '#000',
  },
  earnContainer: {
    alignItems: 'flex-end',
  },
  earnLabel: {
    fontSize: 10,
    color: isDarkTheme ? '#fff' : '#000',
  },
  earnAmount: {
    fontSize: 14,
    fontWeight: 'bold',
    color: isDarkTheme ? '#fff' : '#000',
  },
  reportFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  footerItem: {
    alignItems: 'center',
  },
  footerLabel: {
    fontSize: 12,
    color: isDarkTheme ? '#fff' : '#000',
  },
  footerAmount: {
    fontSize: 14,
    fontWeight: 'bold',
    color: isDarkTheme ? '#fff' : '#000',
  },
});

export default DayBookReport;
