import React from "react";
import { View, Text } from "react-native";
import AppBar from "./headerAppbar/AppBar";

const ReferAndEran = () => {
    return (
        <View>
            <AppBar
                title="Manage Important Security"

            />
        </View>

    );
}
export default ReferAndEran;