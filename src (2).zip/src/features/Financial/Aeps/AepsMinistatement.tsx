import React, { useContext, useEffect, useState } from 'react';
 
import { Appearance,View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Image, ToastAndroid, Modal, Alert, FlatList } from 'react-native';
import useAxiosHook from '../../../utils/network/AxiosClient';
import { APP_URLS } from '../../../utils/network/urls';
import AppBar from '../../drawer/headerAppbar/AppBar';
import AppBarSecond from '../../drawer/headerAppbar/AppBarSecond';
import { SCREEN_HEIGHT, hScale, wScale } from '../../../utils/styles/dimensions';
import FlotingInput from '../../drawer/securityPages/FlotingInput';
import DynamicButton from '../../drawer/button/DynamicButton';
import { FlashList } from '@shopify/flash-list';
import { BottomSheet } from '@rneui/base/dist/BottomSheet/BottomSheet';
import ClosseModalSvg from '../../drawer/svgimgcomponents/ClosseModal';
import { useDeviceInfoHook } from '../../../utils/hooks/useDeviceInfoHook';
import { RootState } from '../../../reduxUtils/store';
import { useSelector } from 'react-redux';
import { useLocationHook } from '../../../utils/hooks/useLocationHook';
import { AepsContext } from './context/AepsContext';
import BankBottomSite from '../../../components/BankBottomSite';
import OnelineDropdownSvg from '../../drawer/svgimgcomponents/simpledropdown';
import ShowLoader from '../../../components/ShowLoder';
import RNFS from 'react-native-fs';
import { isMoment } from 'moment';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SelectDevice from './DeviceSelect';
import { isDriverFound, openFingerPrintScanner } from 'react-native-rdservice-fingerprintscanner';
import { useNavigation } from '../../../utils/navigation/NavigationService';
import QrcodAddmoneysvg from '../../drawer/svgimgcomponents/QrcodAddmoneysvg';
import QRCodeScanner from 'react-native-qrcode-scanner';
import { useRdDeviceConnectionHook } from '../../../hooks/useRdDeviceConnectionHook';

const AepsMinistatement = () => {
    const {isDeviceConnected} = useRdDeviceConnectionHook();

    const [lodervisi, setLodervisi] = useState(false);
    const {setBankId,
        bankid, aadharNumber, setFingerprintData, setAadharNumber, mobileNumber, setMobileNumber, consumerName, setConsumerName, bankName, setBankName, scanFingerprint, fingerprintData ,isValid,setIsValid ,deviceName,setDeviceName} = useContext(AepsContext);
    const [amountcont, setAmountcont] = useState('');
    const [servifee, setServifee] = useState('');
    const [otpcontroller, setOtpcontroller] = useState('');

    const [paybtn, setPaybtn] = useState(true);
    const [otpservisi, setOtpservisi] = useState(false);
    const [showdetatis, setShowdetatis] = useState(false);
    const [aepsType, setAepsType] = useState('AEPSService1');
    const [viewVisible, setViewVisible] = useState(true);
    const [viewVisible1, setViewVisible1] = useState(false);
    const [isScan, setIsScan] = useState(false);
    const [uniqueid, setUniqueid] = useState('');
    const [imei, setImei] = useState('');
    const [responsefromaaadharscan, setResponsefromaaadharscan] = useState('');
    const [adharIsValid, setadharIsValid] = useState(false);
    const [banklist, setBanklist] = useState([]);
    const [isbank, setisbank] = useState(false);

    const [isVisible, setIsVisible] = useState(true);
    const [showDialog, setShowDialog] = useState(false);
    const [status, setStatus] = useState('');
    const [amount, setamount] = useState('')
    const [date, setdate] = useState('')
    const [bnkrrn, setbnkrrn] = useState('')
    const [agentid, setagentid] = useState('');
    const [autofcs, setAutofcs] = useState(false);
    const [isLoading, setIsLoading] = useState(false)
    const now = new Date();
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];

    const dayOfWeek = days[now.getDay()];
    const dayOfMonth = now.getDate();
    const month = months[now.getMonth()];
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    const formattedDate = `${dayOfWeek} ${dayOfMonth} ${month} ${hours}:${minutes}:${seconds}`;

    const { getNetworkCarrier, getMobileDeviceId, getMobileIp } =
        useDeviceInfoHook();
    const { userId } = useSelector((state: RootState) => state.userInfo);
    const { colorConfig } = useSelector((state: RootState) => state.userInfo);
    const color1 = `${colorConfig.secondaryColor}20`

    const color2 = `${colorConfig.primaryColor}40`
    const color3 = `${colorConfig.secondaryColor}15`
    const { latitude, longitude } = useLocationHook();
    const [ministate, setMinistate] = useState([]);
    const [ismodel, setIsmodel] = useState(false);
    const [Proceed, setProceed] = useState(true);
    const { get, post } = useAxiosHook();
    const navigation = useNavigation<any>();

    const ffffffff = {
        "pidDataJson": {
            "PidData": {
                "Hmac": "/zROAbRMsJjikIMudnemldQSvaU/yjUmxZW51Cat+bLqQyLAWqG3n9kwwS4Oz092",
                "Resp": {
                    "qScore": "92",
                    "errInfo": "Success",
                    "fType": "2",
                    "errCode": "0",
                    "fCount": "1",
                    "nmPoints": "56"
                },
                "DeviceInfo": {
                    "additional_info": {
                        "Param": [
                            {
                                "name": "srno",
                                "value": "7396113"
                            },
                            {
                                "name": "sysid",
                                "value": "14e7943ba5e0d629"
                            },
                            {
                                "name": "ts",
                                "value": "2024-09-14T16:57:11+05:30"
                            },
                            {
                                "name": "modality_type",
                                "value": "Finger"
                            },
                            {
                                "name": "device_type",
                                "value": "L1"
                            }
                        ]
                    },
                    "mc": "MIIEADCCAuigAwIBAgIIREM1M0VENDgwDQYJKoZIhvcNAQELBQAwgfwxKjAoBgNVBAMTIURTIE1hbnRyYSBTb2Z0ZWNoIEluZGlhIFB2dCBMdGQgMjFVMFMGA1UEMxNMQi0yMDMgU2hhcGF0aCBIZXhhIE9wcG9zaXRlIEd1amFyYXQgSGlnaCBDb3VydCBTLkcgSGlnaHdheSBBaG1lZGFiYWQgLTM4MDA2MDESMBAGA1UECRMJQUhNRURBQkFEMRAwDgYDVQQIEwdHVUpBUkFUMR0wGwYDVQQLExRURUNITklDQUwgREVQQVJUTUVOVDElMCMGA1UEChMcTWFudHJhIFNvZnRlY2ggSW5kaWEgUHZ0IEx0ZDELMAkGA1UEBhMCSU4wHhcNMjQwOTE0MDYyODM1WhcNMjQxMjEzMDY0MzIyWjCBgjEkMCIGCSqGSIb3DQEJARYVc3VwcG9ydEBtYW50cmF0ZWMuY29tMQswCQYDVQQGEwJJTjELMAkGA1UECBMCR0oxEjAQBgNVBAcTCUFobWVkYWJhZDEOMAwGA1UEChMFTVNJUEwxCzAJBgNVBAsTAklUMQ8wDQYDVQQDEwZNRlMxMTAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCaQYmYFcx0HL7Zcyf/D9tspUBoXCm/22Zq9F7dkkcBm3NIT1QZ8c6+8PebCSgeiQIFtyKNJzHi4rMQMSjoDkiq9vvWXOkQOiHef3pYtVrKT5ecUMOWv2JefMqAd/G2EOGR6ZICFfJ3xAS6QDU8jLldQKIj/R7r0TmVlDud606WjsNoKsX9XIx1CChstqu3YojHygrlUitdfXkz9Hgwft4w9fD6zMEXIKOref8Nq0NTKdyOY3zhJ584pcJ7PH4gvtfTrMI3gaL/4aQqrCqCjCSDLlpY4qXgli9ssMqIDuU6poTMZIBL/y4ShB3TxVGzpmVTsX0qLFwvu+7l0wd5nfydAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAK5SJBpn4dzrr7gwYg/0D6siegcS9D9aS+xBcs4HDG+Uag5d0wlyb6b551451DeKWZvIGuHTEKo6g+dFwjY0dGIpL5C0O2zagPXFQM9TMiL+5EfC98ijG/heOnyEWEKD+GoEMTYsZ1bXTPRM7/YuKvNUysKA4arBlp4hT2S4h6mZ/OJly/PJbj/VsuHIVsqi7vdxMesswkh5H0fbCQwyQvAalBxmolY6y1N3/Br8kvYBlAPfitgoqNUxfgiVROg48Zr/zM03zqBJ2YbJqkLOfQb/4nJIR0wl9l/CYWDOwpdKbBNPivQNj8VsLrL/wtGA5aTS7divpwGgg90FtlGXXIY=",
                    "dpId": "MANTRA.MSIPL",
                    "rdsId": "RENESAS.MANTRA.001",
                    "mi": "MFS110",
                    "rdsVer": "1.0.4",
                    "dc": "c5db1ebe-74c1-4cf1-a317-f76865519966"
                },
                "Data": {
                    "content": "MjAyNC0wOS0xNFQxNjo1NzowM7Ou0gR2QaiKuFoTaZtaXsMZFy/t8xWKvvV6iXQyyPpuW+9L7xL1/VUzgKrF7vGbnpT3lijzXZo/Tq0A2YC1Ww6c6OGmDvpyyG3MNiSqzB72vRtvpU1jjdHSIj9B+Nw3rwWCYd2FHOPpDXNPui28QPaWmJNaWkNQwFFSoUQFFhvJ3PvpqbFERXpu25dNv+UqJFL39MBanuik1HVtBZoN4f4CMVHVTVp11/LJtA6NSslnxOfNvaW2qzRMlaQuptdNJZtHw+EH+YLl+4fssAgiZZzOLgQ4fSvvjJTpKbTAARIYtM4swvI8Me7mpLRrVVgeY2bmS1/R5M8HHOO4UV+eDaRc5hRHMFG9pBAJcLNV4HK44JCbACpjjXwb+W04ZRVv9XkAa9gu+Mi/Csae85tbbh9J1u/gYQyrkCmWfabAWKQnESJSUg3XLQ04DhIX5qHYpXBpf9EKt99B5NqBsw+S9KIWSoPyZcmIM0LKeacZfJwuL8DN9FNaDjgCjyETPvzK1PhWkdnpxSY/4Cu8mjwBlHkmaDjj5XxSi1umrgDN5Db5wyYxE03c/1WIJpuyqr875afc/P/lYxyXgqBZRTVZaZYEq/JcJ14Z73vb0lvSwsOAPY3J7lmZIXjSU6xpfMAj4UmTqP1ERmJq7Z6dwmPYbIS9dWV75YvzY1jMGNVAIybLzBvE73oPnHExA7xJ7x+DgZ3kok2W2sRgQLv8wS8WTf8113IJ9umHrG5cPz8aZVsaXELjShXWcF2IMXR9af2lNBr3WgN3pCWpfKvgBsMAJSi94G28dn/6kM9uhgSs3u4PB/IVBXos3P3Y7i+BsQxnif9gMWaTcoL5GyFQZUKC6P9xBWEjbA5J0k34L4+yOHL3rF/RplLWua/Zb8AnOKtYGYd20nBMm/iSA5chcLDK/J0W6gnUVifqMoQLrMPRSye5tc60LX64iZ4cZYrCsBVPmfBDPxVNAUP2svKgWeyFCQLdT2q1AZGu/5WvPoHoeD6eFpM3Y87bFd5SXPY2YBYX0+Xov2qHrCpURlH5oieTk0/QvOPQg+fogpap13Y9nOLHqi2BiM0VraKWEj4QcVD3W9EjqSkFiEO5dx/5sKvaFZz8ns/JIYSVPyiMZMAfsCw+uBTndsxkATRMYw1wU3gP8T9jBAfFhVI183AERNNO8mgxsNB4rZ0zNu8krTNdRVSxOkX9BO6eh+N++Kv2e5i9HmG3ScaEzbZqj41371dT5ulXpSynuIw5VZIqZ7wBHsKQsRLhJV615DaHcXRUoujBU7WhhP/9Iinp4sqTiabcG2wM+FOJZPFyEf6w5maCRKnZimA2tJQRPHdZYHWt/OyPaQN+CkPSVNoWJuUqUKM33ZdtoesrrHiAd0cwiGsG5rQH8ztoaballNKKELwjDjOcAYKaelQHGnvKMD1yR7M5NOtITZqYyevPOS//A+8tOf567ADqb1+dPipNqbYs+N4Pfn/VzhDOl/WeVUolkqsY2jBwJ1suNo8udpDvs3DTaaXcU0rv8MoFYCWYC/9gq3328gTBmuaeWhCJMczVov40G1fm++s0lzXh2oDFPv01ceVUNoQi+xuTLz6JjEnTN/aFjXGq6rzBaB3f6ZrpfMCmhSm/taRUUSVxPtqr5hL4O7wIeF7L6y9LZ1+qodGQDytAMU7uGHRimwcLTo0bluwKS33FIdLiD+xqxDbJ1fJbdtT49XP0kesyx0Sy5u1f+/P59Q7ONwAuPLyD/kRHdp+yDZAIgXL7Ukd/LbsbTHMEUhjdF5s9fvUmFAbIcuzHTGU1cfPDbZofytuzgZa24Hd7yEb0tu96nJU5AUYsqe5ikK2d6WJWW/6ZIeQlwiscmbrO8qf+D1/w2koUF/9z16gQgSKXvU5M78ux5SeU80HcrqqFXcy3Rr5B0uHz8ajkDStVsJ9qEGiEqjP36ryvHQGVDTm75vpAWMEvG5wX/RgnhO+jUVlZxDmGh6cjR3EMJYsUhJ4BrFZYBP+DQeEsXRQZbT+zUJhjRjQ1aCUzXiYAm2ZeGrJQxFn/aPWVPXrCgYdmn5xazGQ/0jPqfD8UXJOXKx3XTlFRT9n+8bOf0P5JRAPl2ybUv5fLmrUCwUGIOsTCZaBYo8GsOEsab8GB4FPVIkMLHxfBTeqVPbGapujFCiXmIEyrSGiSCGmEG8BAJ4ieW3dzgjxC2972k/QaZ62rjoBkKQoYHCGobLDPtHs0fRDwC65XHFsU4iAmHJQKz0bSrjQPL7P/5x4vDU+QIn4DZrih87rl+SiQTNY8ABHlm1NKMT1WJmiKmJUmCK+s90fRUYqnp50eNgMat+NrrwYoccJeg4BEOG323SxTO5+WRnaWnBB6AYh9RQ/dAU6Z1YeFyQTBUjeRQyOpiKup1AHElc53bsLgGaVWem1ea+WfBAZRUm780flgJ069a0MyyqYPYsVlkaSd+D7+t3QuAw2yOG6eXBPV5jVeiNEhfq7Bhi3OZsCvQ1/H2YsoHndGYkUmbNrVl1j+6Jui3ssOXDG65y0cAcipHOgcO+Fbe4Ahpo9hWCL0T1zdgkvae36w45LyZX4aKmb1Qjw3hG0fReRAgbBB4Pmb+rQ4cnAj1ArB6MSxCsW8ui245tfX0rVt0VqOF5CD5T3vWpT2uGTOmsdwlc9S54hsDOS2aLTgt2yDP3r2kCKJ7cslq3hLXAkIWOM6m3UJhTQOwvxfM1bX/vYhM0wKsbCHKNoPtCVQYrTagBm3JnW8PGmym+3InihVjgB8sJEZnlYlSG1j4hb/XrO2aojIBaP3xFDDmBdeIIMGMl5E4ncayZL1biavycTktOoXtXzRsuDCr/7yTepVSWgAcznwHbX9qfHBnh18LiQaMjSyo/mNAEs3dw3KiwbDNb4wT7e6QJLtiL+u5act5tDOn0rEYIFgOLjFc1er6CFQx5xHPvFTwbEvvXn5tpsexU1tbeeEehXnykjJUbU5+/9q8cRDrX3cqyu4ZFZ9xSb58bf1hRlOFXtIdCbhw4kSpPqts9NBfVSxP5EeKjZAiix1hN1IEPWEYkBjfQb3wwzDtH5XNX0JW2aZB6NpmJ/FAw2g4FE0/uwxuqvqqBFNBBg18CYKsvoiCVHJvzpUkj9P2X6VVZs/jQgwRQbjRlrHDEhtlRxnNx9BRlEPtmJOKHy4d2SE6Ss354E5njLj4Mz4nNh5p19T2OXaXA60DmWxZ2WMZWKqGLYDsIFQFylXqpiVwh4kuhg/559lG6X/Hq+3yXrNoP2H65ro1xsVOTqDrtio37Pq1LJdUKYyn3LVSDojBPGlS7dtWjx0RzHD1B36faUyzqghLYb77uGb2YePzCsLcLYqGHGVa1Npytl6HHwE9sFx1bbVUFLMZzuPLqXIUZq5gIvBqIUCaHL1wUoxuj0KaAlny4huOBPWfV9a2yyQyqqjE2XsTDZrFe77YSdh0xwmWuuRneSvrP8AYtThW/RglFi6kGgl6TtU8tm1HoWFCoFFRz12mc9ZcUtCOOFDVV1ONpK34jahw/vWrbaZFPF+tEDbI/Gq/UMbwwiy1BxuustIIPmITe5Iz63n1UOre51+Qx55bOKlu7ETsGqmIHKIaZKxl+240GDY6pba27L1pCPtANgj62J/KEyV+MacauKUykukrXGuGeQ3bcX0eKNlrYg80Y7uAt9IHoboiYPt4czALzk1bmwvGp4JPZQUyDzgKaI0i69L2T3Sf/4GYvxLaorURmaIL+HWXmecB/hUC0Rf7eQGGT9X07uw0bypqgHdP9QFOfK/AOuRdYvA9FNf31Y5h6f63MUFw9Ep5N3EQBdxSpzjZ8HeK2dGWyZv5TsdzOFfiRdITAZ358xML5g58lW/gOs/stJmjqaEHZe1ftFXuskGhLKhs90PLjUOn6gXEAKvBjkPffmRJDgB+mkrkUydPjznwnjv6RJ4PRPUWcg8CzM7oL61dsGsJQxh+etj7AK5GuEJadJm5E+fyulWN8s6AcrYGKaxllJUKvKUCWIx+rsIoNgeLAR6Q9ukmOW7ce8b71NoT/87edB9cEOswxQYec/f8C3C0bKIA6qIJAMYbNw8WiyE6eSL5BH0VzLv9UIny0RyAccIJrrvpjfTQ5LUaRt6DE3NxNrwtEdwVobBy0fKRKxpXbXVccjRGCRl4mC0Z/WoU4HIV5L45BKboRwehoZ1YGa2pHNaSKAYBWArFdM8zICJG5GBJfgNqaEyr6ZR/GSFDwPVSrB4YgUz+X5OjvhBcCrCbrAjYGuwKUSYoK+HTp+xFk0TNURAILe2WncBA1ZUpqDegCQ7LfX6MHTXPHHJIRgP/iU/59nIbyVQlpOVlVn1/VuD4m1hZ1NOu8/RUrEpbIHBUH9xfVLE+LH1hANyP2Vgxvi4IGnmZ7tHDq1GhzAMqd7vjP3/yd2hWGF7rFdpxNyN/7dXlB4mXksUnwy7ugy9Z5MPKz4hpCFhpyD7HRKWnb2JJvkQlmUk5J0/tqMbCGP4+wAbxiapI+vNWaM4oXgp5OhnfmrY9xmqR76GXEG9Zz5Fad2tXr2t6DWe8EjFqeW9RaIZHPn3hY5aihtdVLnn9WlP9CI2WhZ3BKWeUBmRjLINHgPb6JLJofsNaub48QCLgozkgHuteLmesD7mbFvKmTIsPJtW9og0HhzjmvEHxOd69hn7h07FE3D7rZ8F+5Chklmug+5+pqRuN6sN6r6g1XgWBAHZWLOJFE2pmUog+3ZkOWUBlAFjX/+CSYhCSXO1dEpfnvZyz5h/IRDPUwm8Kp/aRxusyxkjdeGaKD5nmGTD1QlpQvSmK78JG4ltTTkd0dXsAJIbbc94wqRyCcX6SwsJ5HT0VW3uIGoiwbJp+EeRwU5bkQvUXm0MJcXjJCiJvzHTyPe0KlolRODQ/ndwAa6Z6y3xV3R3FIpiD52v1VN1ij/8uXahldiluFPVGCsiP3GVEEI9KLxSl520OAkzEZ38eo3hxGlWKUeC/0QndB2ewKIfuRTTzk5bSX9Y7FEcL+VtFKPTA+NREswHyc2UIxK2v13c/Ilpr5jgqPKca0KB/+QDY1zVax3NsrjAjyB+/SSASh/IBZR6dczkhBXwHSZX5DD2UcQqMY62MqmLDQVmVD2cao7PvCFhBdDcbeSkMkejXZcOJPsw9CgxadOwLx5VQnmMz8iSldQnG7amBOZ2d6lCnxmFg1ZgxPUxoYqILlHx7KFmGo64zB29+wsKe6b9V90eIEPYu4vA0Ewj+BS6IfMYPA1iHCiioD5WPFm2AvweH29mWb9unxybn7IPNFZiPzeMesiPKJn8itma36K2GOA8nuni8V/Cr3wu7/eLQn5zC3vweEbnxuJECEAkF9JY0YCFfPGToEZ5r/+y9qKUN+sOb8xIdXz8rlxprwhbLssCAcW0wawA9oswD3pJNaCpELcuuiCclQWxFhfgxzjErmuj1eRKcJqDX2VyAOZCMmxHf+4QGn4CFK7VRDdjOrSF45rUGt490dnGJeFNpt1MiJmrNZa18955owqEMe5P4dSr2qUOHSYmnULAPUwJedOaq1rvVtG8gz/GmF2RZaOCP/bHbBGnfImndh7WPDbNJYA2YbQm3+SXeoA7AUM6MXgAHe06DKdShz618zddn56wYzOlqYhALflgMuioILc0DBMRs97dTVVU8toRnC+x/Q0stVTNtCUK0reCJ5w2tZI9O0BovrBTRuiwgukGM2wn+5krE0YVudeiTkC9Dc/xcN8bPj1aysbZqmeYh0wCqBOMxlwF8SwosPAKA20JRU996HS9VJJfUrhsxLDKaydJfxb6Lx/NjVm6GAOhu1M2eU+scVeVu+rpoi6UQqKgV9EAFlFBsXxBEnDGD93vPNEXlYEn2EuWkytjwMq5SDoiacdO7E5tz5tL0gL3zjEJ8aFToEUg0jADRcn5xEYGM40CDlB/Non94eWTz7n7zgNXkq4hU9/btnpN3y0sR+VHyNEikQ6C8ORzBdwjBkHq42f8XIdjeEqiHWbqbEiAdcvdQMQytcrVQvTWY+RBRmap7Rz2FyN4reAx4X9cs4mo6xBbbvKBXHOoRNo4oUyyuwmahHXi6Dk9j0gMA2RAHrgxqvBf4Phrg4aK+SniXQIQVW1SSgXFuPmwj5eGC8SIIDwrALUHgesvRCsDX8NxdMrYu1kYlcxOVrblpsVWRt8B44jOYsA4Sq/Mn6UIL8Unp6FeYN9hejHZiNc4LFuSYdnUC9YOajz6WBtmXLyyrlt6sMoUITclPm+KAf/6bYNaFbYrDP1AeYCSrgPd72nQw6p4oqV0098LGP74AlW/tcCAbc8Zp4qfdcMLWgoRiMNplFZT+tpbuVjjtTBSEc9mxii7fBbc9A7Btj6an91kHCg5f+/poweW7pCwaYzAG+KuWaLiRG7oSZztTqSg/UFhfDY9yHcROGkMOt/dJpFGc8q+vA7kBL91I1N6cqIORFXe2HJoM7T2EnqvmS7bSpF/64OA5cq2Yaga8vSya6IktbYKjRYLPGR+SmQptFhOvIDBfeZnzYAgkKKJuI76vYW5RCjiLqr0ol9m+M7yeJ3Qq2T4y9hzo1f4v2wxmKn/51CG06grxLdPfsS5OUqX0NUYLR2P+ZCPWnKYZ3EKe9BTtTpxcj91lQO8WVX1D1w+VpeQbSoRPuyF6C/oq63ya+f6NGMXU2xW6I5KnlGdqYEnmdWoeRlTz/z88Lbhl4+UUfTczD/zzafKbiPTSqSBu9uLbJVB/pmQ8fyRECrW9gnejy/5dYEXXhTEHk8zjeYKT118NU0r8gMJqEDMB98zWBe8sznbvuHcmi4kRUQMY0zNCTzB4mi+PMYhQ7ibJdt72ffR8mp1eAWE5xqbVCdcVHBc3KlXGu0JorLvDFYBXLN64BBJFeOorQLo17KmrLgnVQJT+uHsvbRMhc6KD0vPMQbe5/65DFS86bYurNu9TofwyYZCvtZ7xh0ObUXvH8t6fLErlC7wzzji7iPPvQOU8bUEIu+qCxRyaCVyiTNhM/WDBQIO47JpW4r1ywxFoe6EGxSkIAdBk9wB4KYomGuQq17hbvRqC1KqjVOnZfqLb60NY6XXSP/SAp+UE+fh58FVGKf6Fh0f5IA18iVjiw9SgdfSVXxkMFx4q6/DUXhbyMj5SeL/5cHC/Q3y9+ojCC3jBIRk03398wPhkkYYlWVzTOcXgKCIFhzYwvLHMhBAEZYedhl7j80q1n58x527Cg2edhKwieD5U+JWAdBxNO4NN1VeybQSN4o6gB3Zx6V+z5kw9GrGVX15kxg+YSDQwgdumOpsyC6EiuaEiX6iOHSDkS2rYHjXThGz7ZDwM5Xkbo6+0YrgIOuz+p1/ve0umMhNNJOcTMTaqip8alNdJpQpJy9CNZwOILSCksg6KgqfwT1QHzhpsGICPp6+x+L/UDljcdFvxahBPmXwAnC6zFhZFQte/koJb7N2LzAKJYeWrfC/dTRFAjGSXEGnM3YW0fTFq0o6vY+ew7qGlM2dDfnKbJvwVgJhZEzQAu6fy7JocpY9gegQrNhKBNZtclVBeY/+WV6mWXSZbUnoN6zZ8mS133XrUiJ7bw7cfRwqLPIAmETB3F9cBJSzLXPMZ1JuwwNuu5mQbJgEwjG82bmPY0nOkASDGY42DhOOfrMEuUnkwsWIHEIgAxt/LjcIj/W4Ik2v74m2GlRcSfkD+QFFLXlckwTIE4evWW6BSSkzdcovnSC42gvWL93VxhfnFGXhgYtpSzPAhNvjXDO9mEg3dbRywaVzpeJCnqr9xnrr3T8j4TvGJT5VbTckVCyyEXQLBHjin1fe3a2TH1n8IszykOmphQH49xrupj1gI1UUx+/5tKQaSLvHpNn8/CWXRKSe9wIb/GVTsdkiGbca8jw2huSQMdlYDbu0t5rfegzoxcFpCHnygIP2e7mNfen9vgxKP4rolE2/SWQHonmrnEw0nJUHyQHRcwiiHfCrQpkn66Mrco9WGjb+VfOtVbOJJcdB5C5cDaGq2kJE6ucy9kDccqzWVHdZQFaAmdNwENJnDaXdXJVynptuCNC1ywd2DpF7lZQBnxeIjlZYrxD+4ZQJ/b5FGvKSvdIcCWdQbm57yh38SyGziaCznOJ54HwSE9D0hMDh/FrF/NrB134jy48ww7AvPxVX7rAFS58DfkRa0tgoDg7u8LaGIf32LPzsZSWdns5x8B0iA+xNhoDVQjzci++Ws0qDhzlHa85b6+m+EQKMSXytfvX20gLV0RVijWzEdJAorJpokDdGv/HJ3/adanLINJ9pl64lrWaGJO+EYLkgPj1ESwWiZ4K0CTsCOWMr6WUKPUUrNw6YKIO9d/Gntf9q06LNA42QaNf/ko+jL3v60OSMLeDdWNIH8s28c19ER7OilbIA3IbJSZ+cQ44K4NrYXvIaR81B+H4rQcc+oR+CJWt98pRykuBHJz8xM7qjCF8YIVzqF9kiR9kdHlDjiGV/dvlnHKyVCxlDFS66zerIBpS8SlrgLo87psrI/9vxnwKjIX7BdEzxWlzd1iZ9B7JIMXGMLSTGNPnYE80eTFpNU0cQZsSXVM+LbMVBeePud0egW5ex7JFBqUDgFHpAII/PueAXB0D6/ZoX2+DH/LVJ9YL3RvamwJao0k4A2KhUXjtIAu5TMA0zoTtJWbBWqE0kOw3enapPTyuHTabl0uYyJX+20Bj9F12F1fPUENE3tBzkUdscYPe4UkXAfd1/z5GyB/cz7652aQKCfQL7n55MiLGsFxFQOFBW8wYBPHAYNJw0k6W1AV7089O+jpZcMSeAlG/wbslHmAHoGMkI1w3jSH3T1KmV9y1FPPZqQ/ujjz9m9WDAEeN5xqKAXLVvLVMZ5sewQvyNKKCMzQx/2XZ1z4rWyBskp0zSu8nJHmZCI6FnWQzIVWJkxzbOwMvpgpwOVCQg9Di/ahPMbwyZ8ImCFSC/5/MVnYwaPcGz6mcl/HmUbfsGHcsFJniYhAB1iTW9XKpAMJlfgFFQ7v5jzgtKq6Gn3haWse7XKFjtoT5agWwWwZrJqwhOGDAScBD/5x9wsrMOpFKSVWmbgEX/DTwwbROUQ9GK/htsy1c8riF9Kx44xqbku5ZwG9g9k9BY4KCACaal5H3asjR0VEd3185YdvyBRceDIdqSJ0dRnzkgJcxlIqgGjmPXjk+dejIv5veL7BcVC7RCsniPPGf8/IpN61Nb5UwwMUxOnvFK+WAKYW/tx6687XvqmwM6T7y6BFfSGmmUhLgWWy3pVIabM+ef0wYbDw+acO8DFRoqTT50evkBauwImdEyQDXklYB3fj09vbWmyrQ1L3d4kqhZlhUUk4Yjr8tw6eDpKkTEqBHAOnj19g0rz1OsrmD4hsL9CLdQww/Pvt2envhYdnrusFt68aS3ukEdvPyQhSFafj6kr7gzQXwAvpVM1iWRZ5O5c1OUlbuExVg3l+PyRuvGYGJZOjqycrISO4DOXkufmJVqhmtXouFPYt3F/K+ZjGg0Nhdi46Wl3r2LmPfo5SYWctwZi19ovmfi5TRqNKUIStHlqZv2kzm69RrY0eL3JmGhDl0+ggHUBQMbx7HGtGAX2gSd83Wp1XjwN5+y40sRyHv+54sBq5D/Tyg5FaXxQTltiT7ulYc646LLr3XVYXYMVrOXwx2jAQzZd/VzmzFENe6W9LivtlmqktXJtHf9lJdbip6ccVQWpsjD0SaiHc28Ds3FwZeJGPC5HUAkFlaQh1vNdp2mlmad++t82tM4+O3tK07EuORZkMaCI7rK+uR6mWTy8lQ5FUogotaRohy36LkyXPMM10Zt+dt/lDJBeUKYhlW1kw4BtqaPmCnP5UHXvKkH6yojjWm2bo6inRjnuAELw98PdwkOGafx3bRNfICqaIRDYK2FvsopmYmup+zZAovOWgk/qDR7gNd0h9auboAt4nJgL6rgJSLycb7IMPGwTRYrN6NTlMqVFIxRhALXcaUNiIZdciWCr/dr/B7dAZp1oOEMz010MLnR3MJl6TGccchHWygZYWXzRunayxEH1ECukWGpe9j2xOxXnkvs5igrl2U8T9hH3QY6nelsNlnvLzqn4GPTccfFCjIAegp/KLxbBDRxaLcW0ayEn3mJhBCitajbd0jrVMMYGC7/EEqt4PeX71BXtvsWT7whqGeSiUBRO5C2Y6THAp6ayqjPwCEhZJKsmCK7yNwwf67sITuqxqeySmwadiNy8eGhJA1FyC2FRJMEVsQ750sPKd9RMiG9uYF8EBxGPBPswF6P/opgDy76DJiEKKMYx/Ux0QLoAcxQewLnrQ9IKy6RVX7Sw/0cVuGlZ+tm3D0KgBzFJ9oUM55nGERJy8tBWrB8dFcUODmgKcn3VQvIH6yMxLJtsnWGUwf63BwPyULTFHDSiEnQ5M75qfplsqUUuZVmXvlreZpE/s1Ylsp2+lX2SOsboT1PTbEFo9zdluyO6BpCh0JEhMvkfccTzAEetmQGhRPHjKxVVrbsmifTo/GKEG02C8Kn1nKw/P7MpDviGh3emjM1z/Cr+3BBmfUoJptgV6b4Psq6p56lm0P5Fl4Cmu3We+HlVb07h25KYwM7k6IRfK24k4yrP+APaNXf2NqWf+bT/e9M+bpM3qWznSWXEz3QmEktPKWGPWOqtslO6r2G6fQuhg1Q1rjritHv9aslzYynKlrUJ4+Z4yBmvduCHffrIWwniKKG4y5bT/NDsvZWeET6uBGrPBY2iDWh4QFYrceRzKWQLQdlQefkkw6iHWswb2Dcq5q7goBjxysx2nAcleXLVcrdadeNJqIx2FzCLBjaXCTO8n/xZbxZTzdjnkgNKxjStuzuviedVryoMhD2ckAG/30n6KhqkVYZ/M/y5elu9EJaiRyRNBGnJG83qEdr41wNJrIUh0tybCKNAK1lu46b/WTEpQwIBdq6g2ij9U+cS8ytrzGau0kwGepgMZxTEbuscQ6/TSuJfn+vmt8/ZrzT9UAelJGmtxPV3ZO44S1Wp4PI1uKIDHSCXXVwNdBojxbEVw8KJBqWH6BoDgS0QvIKNnt33J5zvnyf7A0jhqeBr6OM6OfcFmEomEr2CLYsAo9vuIDnqHp+vg4Qj5pSFjlyTibdtHO8B/KiUnrnIlInVmQWA0nUrmVAgCt1Eu/UBEEHWqHHGtzmbCArLwjvwqw08bPHjbd8+ynZBSIkVVGFe2cJhD9LDAnbG9/2t4vpEyewl96NKCd+ubncncnyR8CmHSQzLvp2FTntKTwSPMTce0jOGYMGUElLIwH8xsWovOKDMaZEWuO4OhoKI8mZL+MCITb8jTBPrXp9chRGubKqniQros74s3lc55WjZnDi/DeroB7Qi1buRgNFwN16NP4mP+G34AJPUHQso73i65c4GM1KxHEK4/yzjRKiG0lY3hwDTGh8odYMM8Xa2ryYL7CU2wtPieE5KFfjOefvWJnd2mJQSCuhUHGHl6cl0+kVmuZQtFNFBSF639hzW3fxIsCEkbuX55SkcUe+Ki7Rc21XHXF5T5c/TAB8/5UZ10+fHJVPi659ydOJRv1e3r7MQ4+3JbUUavXrbK/NNBPYc51rR6HzXiqL7LrpRjzCY9lPlyVxmImVPF74C4Sxb/OJpEiWvzhl23tkMFsG3mexO3rrQJNE5JPNGNFm2IYu9fWnNp2yhhfIKcVwoNbbvUlg88GRntDCCDPRc3Y+HzJ1eTPFl3pdl+rU3GCGZ8+sa4Gs6iNOih71LWkww9GArP0aBS/nHH/shNkxhm3SyIv1xoK8psdKGmqC38UCnqu34q4eJnJ1LCd0FaDe4CbvQOFhgZRJFCHjzF2h4dauIc3v5lMpxIQW/2qYRTFixLjPnxUY5nfjInxhQ2LetryTmqBgiDt1KXxBVez0Lt9vEk6M7eU9qpFd0w2iMGLhxGvoiwFZUHr9QXZifjgmn6edR4NkUZ91g2ZWGvXLwBmph9pmLCHjFkJ3GeLVTg/hn342lTOIOnvoSgZGlbY4YSqj5H3xROOjRFChvdaIG0XZ0IUN3bptKV86d/hzSlL9b/m7hNDDmJ0hj+rp9zW99ePCak1WKN2D5Axvh9856c6CZZf5S8+haspuQsZnpalzOrBZLJ9DNPK5A530OMitlTLsZx68BS9xPZtn7acTZ5fdkKSORxPm98gD5/s2HQ4WfkjSo7TAfnKk+QoVSCnY7c4YR+U6v83lVy6YP/GgFZw/iT1hfa2Oun5oj3ZaG8VU2IOgAz+HYP8Z/bDHmElWtFwFRu8NQuy+tttL52QxgJ5Ug6r50eHNjxVDnqoOjvnhmmfkNcBfNVRYzNXPvR+sz4K6aJ9VcVJtQeC2I/aBMaku3aEsfHAmpWFO1KCJBqFUngD4eg0rZbUxvPwTWULdyghzl2U9zlI=",
                    "type": "X"
                },
                "Skey": {
                    "content": "bexSELle0MGx8O0ECuuUWs8TbKP6kk/oSIw/O0j7JctUi8ANCtplxMG1UfwMWMWCgNGC1aE59nV5dlm3ZDuLKOCXnfUtwO+ZJ+zg3VYGxG+OmfzqLVEqVbVoRorsum05Wb+d3IimllyvHm7cTs7kHDD3n9JVbHjoBj3dsIW720+R7LVbINTqbcUTfCyzC5Zc5EGSHMVb0/ZVpUYJdYFBga98uuCI1UJtpmZw9AqGecrZEXVhVf662wlEwIc7ymfiIOYuUhgchd4NvGnQXlFgJPFFXH8nVPL+1fNrDX+5T4ISrTQe0jsgD0CuNVnCS//F2Vf0TmzZita3giC8KrS5yA==",
                    "ci": "20250923"
                }
            }
        },
        "pidDataXML": "<PidData>\n   <Data type=\"X\">MjAyNC0wOS0xNFQxNjo1NzowM7Ou0gR2QaiKuFoTaZtaXsMZFy/t8xWKvvV6iXQyyPpuW+9L7xL1/VUzgKrF7vGbnpT3lijzXZo/Tq0A2YC1Ww6c6OGmDvpyyG3MNiSqzB72vRtvpU1jjdHSIj9B+Nw3rwWCYd2FHOPpDXNPui28QPaWmJNaWkNQwFFSoUQFFhvJ3PvpqbFERXpu25dNv+UqJFL39MBanuik1HVtBZoN4f4CMVHVTVp11/LJtA6NSslnxOfNvaW2qzRMlaQuptdNJZtHw+EH+YLl+4fssAgiZZzOLgQ4fSvvjJTpKbTAARIYtM4swvI8Me7mpLRrVVgeY2bmS1/R5M8HHOO4UV+eDaRc5hRHMFG9pBAJcLNV4HK44JCbACpjjXwb+W04ZRVv9XkAa9gu+Mi/Csae85tbbh9J1u/gYQyrkCmWfabAWKQnESJSUg3XLQ04DhIX5qHYpXBpf9EKt99B5NqBsw+S9KIWSoPyZcmIM0LKeacZfJwuL8DN9FNaDjgCjyETPvzK1PhWkdnpxSY/4Cu8mjwBlHkmaDjj5XxSi1umrgDN5Db5wyYxE03c/1WIJpuyqr875afc/P/lYxyXgqBZRTVZaZYEq/JcJ14Z73vb0lvSwsOAPY3J7lmZIXjSU6xpfMAj4UmTqP1ERmJq7Z6dwmPYbIS9dWV75YvzY1jMGNVAIybLzBvE73oPnHExA7xJ7x+DgZ3kok2W2sRgQLv8wS8WTf8113IJ9umHrG5cPz8aZVsaXELjShXWcF2IMXR9af2lNBr3WgN3pCWpfKvgBsMAJSi94G28dn/6kM9uhgSs3u4PB/IVBXos3P3Y7i+BsQxnif9gMWaTcoL5GyFQZUKC6P9xBWEjbA5J0k34L4+yOHL3rF/RplLWua/Zb8AnOKtYGYd20nBMm/iSA5chcLDK/J0W6gnUVifqMoQLrMPRSye5tc60LX64iZ4cZYrCsBVPmfBDPxVNAUP2svKgWeyFCQLdT2q1AZGu/5WvPoHoeD6eFpM3Y87bFd5SXPY2YBYX0+Xov2qHrCpURlH5oieTk0/QvOPQg+fogpap13Y9nOLHqi2BiM0VraKWEj4QcVD3W9EjqSkFiEO5dx/5sKvaFZz8ns/JIYSVPyiMZMAfsCw+uBTndsxkATRMYw1wU3gP8T9jBAfFhVI183AERNNO8mgxsNB4rZ0zNu8krTNdRVSxOkX9BO6eh+N++Kv2e5i9HmG3ScaEzbZqj41371dT5ulXpSynuIw5VZIqZ7wBHsKQsRLhJV615DaHcXRUoujBU7WhhP/9Iinp4sqTiabcG2wM+FOJZPFyEf6w5maCRKnZimA2tJQRPHdZYHWt/OyPaQN+CkPSVNoWJuUqUKM33ZdtoesrrHiAd0cwiGsG5rQH8ztoaballNKKELwjDjOcAYKaelQHGnvKMD1yR7M5NOtITZqYyevPOS//A+8tOf567ADqb1+dPipNqbYs+N4Pfn/VzhDOl/WeVUolkqsY2jBwJ1suNo8udpDvs3DTaaXcU0rv8MoFYCWYC/9gq3328gTBmuaeWhCJMczVov40G1fm++s0lzXh2oDFPv01ceVUNoQi+xuTLz6JjEnTN/aFjXGq6rzBaB3f6ZrpfMCmhSm/taRUUSVxPtqr5hL4O7wIeF7L6y9LZ1+qodGQDytAMU7uGHRimwcLTo0bluwKS33FIdLiD+xqxDbJ1fJbdtT49XP0kesyx0Sy5u1f+/P59Q7ONwAuPLyD/kRHdp+yDZAIgXL7Ukd/LbsbTHMEUhjdF5s9fvUmFAbIcuzHTGU1cfPDbZofytuzgZa24Hd7yEb0tu96nJU5AUYsqe5ikK2d6WJWW/6ZIeQlwiscmbrO8qf+D1/w2koUF/9z16gQgSKXvU5M78ux5SeU80HcrqqFXcy3Rr5B0uHz8ajkDStVsJ9qEGiEqjP36ryvHQGVDTm75vpAWMEvG5wX/RgnhO+jUVlZxDmGh6cjR3EMJYsUhJ4BrFZYBP+DQeEsXRQZbT+zUJhjRjQ1aCUzXiYAm2ZeGrJQxFn/aPWVPXrCgYdmn5xazGQ/0jPqfD8UXJOXKx3XTlFRT9n+8bOf0P5JRAPl2ybUv5fLmrUCwUGIOsTCZaBYo8GsOEsab8GB4FPVIkMLHxfBTeqVPbGapujFCiXmIEyrSGiSCGmEG8BAJ4ieW3dzgjxC2972k/QaZ62rjoBkKQoYHCGobLDPtHs0fRDwC65XHFsU4iAmHJQKz0bSrjQPL7P/5x4vDU+QIn4DZrih87rl+SiQTNY8ABHlm1NKMT1WJmiKmJUmCK+s90fRUYqnp50eNgMat+NrrwYoccJeg4BEOG323SxTO5+WRnaWnBB6AYh9RQ/dAU6Z1YeFyQTBUjeRQyOpiKup1AHElc53bsLgGaVWem1ea+WfBAZRUm780flgJ069a0MyyqYPYsVlkaSd+D7+t3QuAw2yOG6eXBPV5jVeiNEhfq7Bhi3OZsCvQ1/H2YsoHndGYkUmbNrVl1j+6Jui3ssOXDG65y0cAcipHOgcO+Fbe4Ahpo9hWCL0T1zdgkvae36w45LyZX4aKmb1Qjw3hG0fReRAgbBB4Pmb+rQ4cnAj1ArB6MSxCsW8ui245tfX0rVt0VqOF5CD5T3vWpT2uGTOmsdwlc9S54hsDOS2aLTgt2yDP3r2kCKJ7cslq3hLXAkIWOM6m3UJhTQOwvxfM1bX/vYhM0wKsbCHKNoPtCVQYrTagBm3JnW8PGmym+3InihVjgB8sJEZnlYlSG1j4hb/XrO2aojIBaP3xFDDmBdeIIMGMl5E4ncayZL1biavycTktOoXtXzRsuDCr/7yTepVSWgAcznwHbX9qfHBnh18LiQaMjSyo/mNAEs3dw3KiwbDNb4wT7e6QJLtiL+u5act5tDOn0rEYIFgOLjFc1er6CFQx5xHPvFTwbEvvXn5tpsexU1tbeeEehXnykjJUbU5+/9q8cRDrX3cqyu4ZFZ9xSb58bf1hRlOFXtIdCbhw4kSpPqts9NBfVSxP5EeKjZAiix1hN1IEPWEYkBjfQb3wwzDtH5XNX0JW2aZB6NpmJ/FAw2g4FE0/uwxuqvqqBFNBBg18CYKsvoiCVHJvzpUkj9P2X6VVZs/jQgwRQbjRlrHDEhtlRxnNx9BRlEPtmJOKHy4d2SE6Ss354E5njLj4Mz4nNh5p19T2OXaXA60DmWxZ2WMZWKqGLYDsIFQFylXqpiVwh4kuhg/559lG6X/Hq+3yXrNoP2H65ro1xsVOTqDrtio37Pq1LJdUKYyn3LVSDojBPGlS7dtWjx0RzHD1B36faUyzqghLYb77uGb2YePzCsLcLYqGHGVa1Npytl6HHwE9sFx1bbVUFLMZzuPLqXIUZq5gIvBqIUCaHL1wUoxuj0KaAlny4huOBPWfV9a2yyQyqqjE2XsTDZrFe77YSdh0xwmWuuRneSvrP8AYtThW/RglFi6kGgl6TtU8tm1HoWFCoFFRz12mc9ZcUtCOOFDVV1ONpK34jahw/vWrbaZFPF+tEDbI/Gq/UMbwwiy1BxuustIIPmITe5Iz63n1UOre51+Qx55bOKlu7ETsGqmIHKIaZKxl+240GDY6pba27L1pCPtANgj62J/KEyV+MacauKUykukrXGuGeQ3bcX0eKNlrYg80Y7uAt9IHoboiYPt4czALzk1bmwvGp4JPZQUyDzgKaI0i69L2T3Sf/4GYvxLaorURmaIL+HWXmecB/hUC0Rf7eQGGT9X07uw0bypqgHdP9QFOfK/AOuRdYvA9FNf31Y5h6f63MUFw9Ep5N3EQBdxSpzjZ8HeK2dGWyZv5TsdzOFfiRdITAZ358xML5g58lW/gOs/stJmjqaEHZe1ftFXuskGhLKhs90PLjUOn6gXEAKvBjkPffmRJDgB+mkrkUydPjznwnjv6RJ4PRPUWcg8CzM7oL61dsGsJQxh+etj7AK5GuEJadJm5E+fyulWN8s6AcrYGKaxllJUKvKUCWIx+rsIoNgeLAR6Q9ukmOW7ce8b71NoT/87edB9cEOswxQYec/f8C3C0bKIA6qIJAMYbNw8WiyE6eSL5BH0VzLv9UIny0RyAccIJrrvpjfTQ5LUaRt6DE3NxNrwtEdwVobBy0fKRKxpXbXVccjRGCRl4mC0Z/WoU4HIV5L45BKboRwehoZ1YGa2pHNaSKAYBWArFdM8zICJG5GBJfgNqaEyr6ZR/GSFDwPVSrB4YgUz+X5OjvhBcCrCbrAjYGuwKUSYoK+HTp+xFk0TNURAILe2WncBA1ZUpqDegCQ7LfX6MHTXPHHJIRgP/iU/59nIbyVQlpOVlVn1/VuD4m1hZ1NOu8/RUrEpbIHBUH9xfVLE+LH1hANyP2Vgxvi4IGnmZ7tHDq1GhzAMqd7vjP3/yd2hWGF7rFdpxNyN/7dXlB4mXksUnwy7ugy9Z5MPKz4hpCFhpyD7HRKWnb2JJvkQlmUk5J0/tqMbCGP4+wAbxiapI+vNWaM4oXgp5OhnfmrY9xmqR76GXEG9Zz5Fad2tXr2t6DWe8EjFqeW9RaIZHPn3hY5aihtdVLnn9WlP9CI2WhZ3BKWeUBmRjLINHgPb6JLJofsNaub48QCLgozkgHuteLmesD7mbFvKmTIsPJtW9og0HhzjmvEHxOd69hn7h07FE3D7rZ8F+5Chklmug+5+pqRuN6sN6r6g1XgWBAHZWLOJFE2pmUog+3ZkOWUBlAFjX/+CSYhCSXO1dEpfnvZyz5h/IRDPUwm8Kp/aRxusyxkjdeGaKD5nmGTD1QlpQvSmK78JG4ltTTkd0dXsAJIbbc94wqRyCcX6SwsJ5HT0VW3uIGoiwbJp+EeRwU5bkQvUXm0MJcXjJCiJvzHTyPe0KlolRODQ/ndwAa6Z6y3xV3R3FIpiD52v1VN1ij/8uXahldiluFPVGCsiP3GVEEI9KLxSl520OAkzEZ38eo3hxGlWKUeC/0QndB2ewKIfuRTTzk5bSX9Y7FEcL+VtFKPTA+NREswHyc2UIxK2v13c/Ilpr5jgqPKca0KB/+QDY1zVax3NsrjAjyB+/SSASh/IBZR6dczkhBXwHSZX5DD2UcQqMY62MqmLDQVmVD2cao7PvCFhBdDcbeSkMkejXZcOJPsw9CgxadOwLx5VQnmMz8iSldQnG7amBOZ2d6lCnxmFg1ZgxPUxoYqILlHx7KFmGo64zB29+wsKe6b9V90eIEPYu4vA0Ewj+BS6IfMYPA1iHCiioD5WPFm2AvweH29mWb9unxybn7IPNFZiPzeMesiPKJn8itma36K2GOA8nuni8V/Cr3wu7/eLQn5zC3vweEbnxuJECEAkF9JY0YCFfPGToEZ5r/+y9qKUN+sOb8xIdXz8rlxprwhbLssCAcW0wawA9oswD3pJNaCpELcuuiCclQWxFhfgxzjErmuj1eRKcJqDX2VyAOZCMmxHf+4QGn4CFK7VRDdjOrSF45rUGt490dnGJeFNpt1MiJmrNZa18955owqEMe5P4dSr2qUOHSYmnULAPUwJedOaq1rvVtG8gz/GmF2RZaOCP/bHbBGnfImndh7WPDbNJYA2YbQm3+SXeoA7AUM6MXgAHe06DKdShz618zddn56wYzOlqYhALflgMuioILc0DBMRs97dTVVU8toRnC+x/Q0stVTNtCUK0reCJ5w2tZI9O0BovrBTRuiwgukGM2wn+5krE0YVudeiTkC9Dc/xcN8bPj1aysbZqmeYh0wCqBOMxlwF8SwosPAKA20JRU996HS9VJJfUrhsxLDKaydJfxb6Lx/NjVm6GAOhu1M2eU+scVeVu+rpoi6UQqKgV9EAFlFBsXxBEnDGD93vPNEXlYEn2EuWkytjwMq5SDoiacdO7E5tz5tL0gL3zjEJ8aFToEUg0jADRcn5xEYGM40CDlB/Non94eWTz7n7zgNXkq4hU9/btnpN3y0sR+VHyNEikQ6C8ORzBdwjBkHq42f8XIdjeEqiHWbqbEiAdcvdQMQytcrVQvTWY+RBRmap7Rz2FyN4reAx4X9cs4mo6xBbbvKBXHOoRNo4oUyyuwmahHXi6Dk9j0gMA2RAHrgxqvBf4Phrg4aK+SniXQIQVW1SSgXFuPmwj5eGC8SIIDwrALUHgesvRCsDX8NxdMrYu1kYlcxOVrblpsVWRt8B44jOYsA4Sq/Mn6UIL8Unp6FeYN9hejHZiNc4LFuSYdnUC9YOajz6WBtmXLyyrlt6sMoUITclPm+KAf/6bYNaFbYrDP1AeYCSrgPd72nQw6p4oqV0098LGP74AlW/tcCAbc8Zp4qfdcMLWgoRiMNplFZT+tpbuVjjtTBSEc9mxii7fBbc9A7Btj6an91kHCg5f+/poweW7pCwaYzAG+KuWaLiRG7oSZztTqSg/UFhfDY9yHcROGkMOt/dJpFGc8q+vA7kBL91I1N6cqIORFXe2HJoM7T2EnqvmS7bSpF/64OA5cq2Yaga8vSya6IktbYKjRYLPGR+SmQptFhOvIDBfeZnzYAgkKKJuI76vYW5RCjiLqr0ol9m+M7yeJ3Qq2T4y9hzo1f4v2wxmKn/51CG06grxLdPfsS5OUqX0NUYLR2P+ZCPWnKYZ3EKe9BTtTpxcj91lQO8WVX1D1w+VpeQbSoRPuyF6C/oq63ya+f6NGMXU2xW6I5KnlGdqYEnmdWoeRlTz/z88Lbhl4+UUfTczD/zzafKbiPTSqSBu9uLbJVB/pmQ8fyRECrW9gnejy/5dYEXXhTEHk8zjeYKT118NU0r8gMJqEDMB98zWBe8sznbvuHcmi4kRUQMY0zNCTzB4mi+PMYhQ7ibJdt72ffR8mp1eAWE5xqbVCdcVHBc3KlXGu0JorLvDFYBXLN64BBJFeOorQLo17KmrLgnVQJT+uHsvbRMhc6KD0vPMQbe5/65DFS86bYurNu9TofwyYZCvtZ7xh0ObUXvH8t6fLErlC7wzzji7iPPvQOU8bUEIu+qCxRyaCVyiTNhM/WDBQIO47JpW4r1ywxFoe6EGxSkIAdBk9wB4KYomGuQq17hbvRqC1KqjVOnZfqLb60NY6XXSP/SAp+UE+fh58FVGKf6Fh0f5IA18iVjiw9SgdfSVXxkMFx4q6/DUXhbyMj5SeL/5cHC/Q3y9+ojCC3jBIRk03398wPhkkYYlWVzTOcXgKCIFhzYwvLHMhBAEZYedhl7j80q1n58x527Cg2edhKwieD5U+JWAdBxNO4NN1VeybQSN4o6gB3Zx6V+z5kw9GrGVX15kxg+YSDQwgdumOpsyC6EiuaEiX6iOHSDkS2rYHjXThGz7ZDwM5Xkbo6+0YrgIOuz+p1/ve0umMhNNJOcTMTaqip8alNdJpQpJy9CNZwOILSCksg6KgqfwT1QHzhpsGICPp6+x+L/UDljcdFvxahBPmXwAnC6zFhZFQte/koJb7N2LzAKJYeWrfC/dTRFAjGSXEGnM3YW0fTFq0o6vY+ew7qGlM2dDfnKbJvwVgJhZEzQAu6fy7JocpY9gegQrNhKBNZtclVBeY/+WV6mWXSZbUnoN6zZ8mS133XrUiJ7bw7cfRwqLPIAmETB3F9cBJSzLXPMZ1JuwwNuu5mQbJgEwjG82bmPY0nOkASDGY42DhOOfrMEuUnkwsWIHEIgAxt/LjcIj/W4Ik2v74m2GlRcSfkD+QFFLXlckwTIE4evWW6BSSkzdcovnSC42gvWL93VxhfnFGXhgYtpSzPAhNvjXDO9mEg3dbRywaVzpeJCnqr9xnrr3T8j4TvGJT5VbTckVCyyEXQLBHjin1fe3a2TH1n8IszykOmphQH49xrupj1gI1UUx+/5tKQaSLvHpNn8/CWXRKSe9wIb/GVTsdkiGbca8jw2huSQMdlYDbu0t5rfegzoxcFpCHnygIP2e7mNfen9vgxKP4rolE2/SWQHonmrnEw0nJUHyQHRcwiiHfCrQpkn66Mrco9WGjb+VfOtVbOJJcdB5C5cDaGq2kJE6ucy9kDccqzWVHdZQFaAmdNwENJnDaXdXJVynptuCNC1ywd2DpF7lZQBnxeIjlZYrxD+4ZQJ/b5FGvKSvdIcCWdQbm57yh38SyGziaCznOJ54HwSE9D0hMDh/FrF/NrB134jy48ww7AvPxVX7rAFS58DfkRa0tgoDg7u8LaGIf32LPzsZSWdns5x8B0iA+xNhoDVQjzci++Ws0qDhzlHa85b6+m+EQKMSXytfvX20gLV0RVijWzEdJAorJpokDdGv/HJ3/adanLINJ9pl64lrWaGJO+EYLkgPj1ESwWiZ4K0CTsCOWMr6WUKPUUrNw6YKIO9d/Gntf9q06LNA42QaNf/ko+jL3v60OSMLeDdWNIH8s28c19ER7OilbIA3IbJSZ+cQ44K4NrYXvIaR81B+H4rQcc+oR+CJWt98pRykuBHJz8xM7qjCF8YIVzqF9kiR9kdHlDjiGV/dvlnHKyVCxlDFS66zerIBpS8SlrgLo87psrI/9vxnwKjIX7BdEzxWlzd1iZ9B7JIMXGMLSTGNPnYE80eTFpNU0cQZsSXVM+LbMVBeePud0egW5ex7JFBqUDgFHpAII/PueAXB0D6/ZoX2+DH/LVJ9YL3RvamwJao0k4A2KhUXjtIAu5TMA0zoTtJWbBWqE0kOw3enapPTyuHTabl0uYyJX+20Bj9F12F1fPUENE3tBzkUdscYPe4UkXAfd1/z5GyB/cz7652aQKCfQL7n55MiLGsFxFQOFBW8wYBPHAYNJw0k6W1AV7089O+jpZcMSeAlG/wbslHmAHoGMkI1w3jSH3T1KmV9y1FPPZqQ/ujjz9m9WDAEeN5xqKAXLVvLVMZ5sewQvyNKKCMzQx/2XZ1z4rWyBskp0zSu8nJHmZCI6FnWQzIVWJkxzbOwMvpgpwOVCQg9Di/ahPMbwyZ8ImCFSC/5/MVnYwaPcGz6mcl/HmUbfsGHcsFJniYhAB1iTW9XKpAMJlfgFFQ7v5jzgtKq6Gn3haWse7XKFjtoT5agWwWwZrJqwhOGDAScBD/5x9wsrMOpFKSVWmbgEX/DTwwbROUQ9GK/htsy1c8riF9Kx44xqbku5ZwG9g9k9BY4KCACaal5H3asjR0VEd3185YdvyBRceDIdqSJ0dRnzkgJcxlIqgGjmPXjk+dejIv5veL7BcVC7RCsniPPGf8/IpN61Nb5UwwMUxOnvFK+WAKYW/tx6687XvqmwM6T7y6BFfSGmmUhLgWWy3pVIabM+ef0wYbDw+acO8DFRoqTT50evkBauwImdEyQDXklYB3fj09vbWmyrQ1L3d4kqhZlhUUk4Yjr8tw6eDpKkTEqBHAOnj19g0rz1OsrmD4hsL9CLdQww/Pvt2envhYdnrusFt68aS3ukEdvPyQhSFafj6kr7gzQXwAvpVM1iWRZ5O5c1OUlbuExVg3l+PyRuvGYGJZOjqycrISO4DOXkufmJVqhmtXouFPYt3F/K+ZjGg0Nhdi46Wl3r2LmPfo5SYWctwZi19ovmfi5TRqNKUIStHlqZv2kzm69RrY0eL3JmGhDl0+ggHUBQMbx7HGtGAX2gSd83Wp1XjwN5+y40sRyHv+54sBq5D/Tyg5FaXxQTltiT7ulYc646LLr3XVYXYMVrOXwx2jAQzZd/VzmzFENe6W9LivtlmqktXJtHf9lJdbip6ccVQWpsjD0SaiHc28Ds3FwZeJGPC5HUAkFlaQh1vNdp2mlmad++t82tM4+O3tK07EuORZkMaCI7rK+uR6mWTy8lQ5FUogotaRohy36LkyXPMM10Zt+dt/lDJBeUKYhlW1kw4BtqaPmCnP5UHXvKkH6yojjWm2bo6inRjnuAELw98PdwkOGafx3bRNfICqaIRDYK2FvsopmYmup+zZAovOWgk/qDR7gNd0h9auboAt4nJgL6rgJSLycb7IMPGwTRYrN6NTlMqVFIxRhALXcaUNiIZdciWCr/dr/B7dAZp1oOEMz010MLnR3MJl6TGccchHWygZYWXzRunayxEH1ECukWGpe9j2xOxXnkvs5igrl2U8T9hH3QY6nelsNlnvLzqn4GPTccfFCjIAegp/KLxbBDRxaLcW0ayEn3mJhBCitajbd0jrVMMYGC7/EEqt4PeX71BXtvsWT7whqGeSiUBRO5C2Y6THAp6ayqjPwCEhZJKsmCK7yNwwf67sITuqxqeySmwadiNy8eGhJA1FyC2FRJMEVsQ750sPKd9RMiG9uYF8EBxGPBPswF6P/opgDy76DJiEKKMYx/Ux0QLoAcxQewLnrQ9IKy6RVX7Sw/0cVuGlZ+tm3D0KgBzFJ9oUM55nGERJy8tBWrB8dFcUODmgKcn3VQvIH6yMxLJtsnWGUwf63BwPyULTFHDSiEnQ5M75qfplsqUUuZVmXvlreZpE/s1Ylsp2+lX2SOsboT1PTbEFo9zdluyO6BpCh0JEhMvkfccTzAEetmQGhRPHjKxVVrbsmifTo/GKEG02C8Kn1nKw/P7MpDviGh3emjM1z/Cr+3BBmfUoJptgV6b4Psq6p56lm0P5Fl4Cmu3We+HlVb07h25KYwM7k6IRfK24k4yrP+APaNXf2NqWf+bT/e9M+bpM3qWznSWXEz3QmEktPKWGPWOqtslO6r2G6fQuhg1Q1rjritHv9aslzYynKlrUJ4+Z4yBmvduCHffrIWwniKKG4y5bT/NDsvZWeET6uBGrPBY2iDWh4QFYrceRzKWQLQdlQefkkw6iHWswb2Dcq5q7goBjxysx2nAcleXLVcrdadeNJqIx2FzCLBjaXCTO8n/xZbxZTzdjnkgNKxjStuzuviedVryoMhD2ckAG/30n6KhqkVYZ/M/y5elu9EJaiRyRNBGnJG83qEdr41wNJrIUh0tybCKNAK1lu46b/WTEpQwIBdq6g2ij9U+cS8ytrzGau0kwGepgMZxTEbuscQ6/TSuJfn+vmt8/ZrzT9UAelJGmtxPV3ZO44S1Wp4PI1uKIDHSCXXVwNdBojxbEVw8KJBqWH6BoDgS0QvIKNnt33J5zvnyf7A0jhqeBr6OM6OfcFmEomEr2CLYsAo9vuIDnqHp+vg4Qj5pSFjlyTibdtHO8B/KiUnrnIlInVmQWA0nUrmVAgCt1Eu/UBEEHWqHHGtzmbCArLwjvwqw08bPHjbd8+ynZBSIkVVGFe2cJhD9LDAnbG9/2t4vpEyewl96NKCd+ubncncnyR8CmHSQzLvp2FTntKTwSPMTce0jOGYMGUElLIwH8xsWovOKDMaZEWuO4OhoKI8mZL+MCITb8jTBPrXp9chRGubKqniQros74s3lc55WjZnDi/DeroB7Qi1buRgNFwN16NP4mP+G34AJPUHQso73i65c4GM1KxHEK4/yzjRKiG0lY3hwDTGh8odYMM8Xa2ryYL7CU2wtPieE5KFfjOefvWJnd2mJQSCuhUHGHl6cl0+kVmuZQtFNFBSF639hzW3fxIsCEkbuX55SkcUe+Ki7Rc21XHXF5T5c/TAB8/5UZ10+fHJVPi659ydOJRv1e3r7MQ4+3JbUUavXrbK/NNBPYc51rR6HzXiqL7LrpRjzCY9lPlyVxmImVPF74C4Sxb/OJpEiWvzhl23tkMFsG3mexO3rrQJNE5JPNGNFm2IYu9fWnNp2yhhfIKcVwoNbbvUlg88GRntDCCDPRc3Y+HzJ1eTPFl3pdl+rU3GCGZ8+sa4Gs6iNOih71LWkww9GArP0aBS/nHH/shNkxhm3SyIv1xoK8psdKGmqC38UCnqu34q4eJnJ1LCd0FaDe4CbvQOFhgZRJFCHjzF2h4dauIc3v5lMpxIQW/2qYRTFixLjPnxUY5nfjInxhQ2LetryTmqBgiDt1KXxBVez0Lt9vEk6M7eU9qpFd0w2iMGLhxGvoiwFZUHr9QXZifjgmn6edR4NkUZ91g2ZWGvXLwBmph9pmLCHjFkJ3GeLVTg/hn342lTOIOnvoSgZGlbY4YSqj5H3xROOjRFChvdaIG0XZ0IUN3bptKV86d/hzSlL9b/m7hNDDmJ0hj+rp9zW99ePCak1WKN2D5Axvh9856c6CZZf5S8+haspuQsZnpalzOrBZLJ9DNPK5A530OMitlTLsZx68BS9xPZtn7acTZ5fdkKSORxPm98gD5/s2HQ4WfkjSo7TAfnKk+QoVSCnY7c4YR+U6v83lVy6YP/GgFZw/iT1hfa2Oun5oj3ZaG8VU2IOgAz+HYP8Z/bDHmElWtFwFRu8NQuy+tttL52QxgJ5Ug6r50eHNjxVDnqoOjvnhmmfkNcBfNVRYzNXPvR+sz4K6aJ9VcVJtQeC2I/aBMaku3aEsfHAmpWFO1KCJBqFUngD4eg0rZbUxvPwTWULdyghzl2U9zlI=</Data>\n   <DeviceInfo dc=\"c5db1ebe-74c1-4cf1-a317-f76865519966\" dpId=\"MANTRA.MSIPL\" mc=\"MIIEADCCAuigAwIBAgIIREM1M0VENDgwDQYJKoZIhvcNAQELBQAwgfwxKjAoBgNVBAMTIURTIE1hbnRyYSBTb2Z0ZWNoIEluZGlhIFB2dCBMdGQgMjFVMFMGA1UEMxNMQi0yMDMgU2hhcGF0aCBIZXhhIE9wcG9zaXRlIEd1amFyYXQgSGlnaCBDb3VydCBTLkcgSGlnaHdheSBBaG1lZGFiYWQgLTM4MDA2MDESMBAGA1UECRMJQUhNRURBQkFEMRAwDgYDVQQIEwdHVUpBUkFUMR0wGwYDVQQLExRURUNITklDQUwgREVQQVJUTUVOVDElMCMGA1UEChMcTWFudHJhIFNvZnRlY2ggSW5kaWEgUHZ0IEx0ZDELMAkGA1UEBhMCSU4wHhcNMjQwOTE0MDYyODM1WhcNMjQxMjEzMDY0MzIyWjCBgjEkMCIGCSqGSIb3DQEJARYVc3VwcG9ydEBtYW50cmF0ZWMuY29tMQswCQYDVQQGEwJJTjELMAkGA1UECBMCR0oxEjAQBgNVBAcTCUFobWVkYWJhZDEOMAwGA1UEChMFTVNJUEwxCzAJBgNVBAsTAklUMQ8wDQYDVQQDEwZNRlMxMTAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCaQYmYFcx0HL7Zcyf/D9tspUBoXCm/22Zq9F7dkkcBm3NIT1QZ8c6+8PebCSgeiQIFtyKNJzHi4rMQMSjoDkiq9vvWXOkQOiHef3pYtVrKT5ecUMOWv2JefMqAd/G2EOGR6ZICFfJ3xAS6QDU8jLldQKIj/R7r0TmVlDud606WjsNoKsX9XIx1CChstqu3YojHygrlUitdfXkz9Hgwft4w9fD6zMEXIKOref8Nq0NTKdyOY3zhJ584pcJ7PH4gvtfTrMI3gaL/4aQqrCqCjCSDLlpY4qXgli9ssMqIDuU6poTMZIBL/y4ShB3TxVGzpmVTsX0qLFwvu+7l0wd5nfydAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAK5SJBpn4dzrr7gwYg/0D6siegcS9D9aS+xBcs4HDG+Uag5d0wlyb6b551451DeKWZvIGuHTEKo6g+dFwjY0dGIpL5C0O2zagPXFQM9TMiL+5EfC98ijG/heOnyEWEKD+GoEMTYsZ1bXTPRM7/YuKvNUysKA4arBlp4hT2S4h6mZ/OJly/PJbj/VsuHIVsqi7vdxMesswkh5H0fbCQwyQvAalBxmolY6y1N3/Br8kvYBlAPfitgoqNUxfgiVROg48Zr/zM03zqBJ2YbJqkLOfQb/4nJIR0wl9l/CYWDOwpdKbBNPivQNj8VsLrL/wtGA5aTS7divpwGgg90FtlGXXIY=\" mi=\"MFS110\" rdsId=\"RENESAS.MANTRA.001\" rdsVer=\"1.0.4\">\n      <additional_info>\n         <Param name=\"srno\" value=\"7396113\"/>\n         <Param name=\"sysid\" value=\"14e7943ba5e0d629\"/>\n         <Param name=\"ts\" value=\"2024-09-14T16:57:11+05:30\"/>\n         <Param name=\"modality_type\" value=\"Finger\"/>\n         <Param name=\"device_type\" value=\"L1\"/>\n      </additional_info>\n   </DeviceInfo>\n   <Hmac>/zROAbRMsJjikIMudnemldQSvaU/yjUmxZW51Cat+bLqQyLAWqG3n9kwwS4Oz092</Hmac>\n   <Resp errCode=\"0\" errInfo=\"Success\" fCount=\"1\" fType=\"2\" nmPoints=\"56\" qScore=\"92\"/>\n   <Skey ci=\"20250923\">bexSELle0MGx8O0ECuuUWs8TbKP6kk/oSIw/O0j7JctUi8ANCtplxMG1UfwMWMWCgNGC1aE59nV5dlm3ZDuLKOCXnfUtwO+ZJ+zg3VYGxG+OmfzqLVEqVbVoRorsum05Wb+d3IimllyvHm7cTs7kHDD3n9JVbHjoBj3dsIW720+R7LVbINTqbcUTfCyzC5Zc5EGSHMVb0/ZVpUYJdYFBga98uuCI1UJtpmZw9AqGecrZEXVhVf662wlEwIc7ymfiIOYuUhgchd4NvGnQXlFgJPFFXH8nVPL+1fNrDX+5T4ISrTQe0jsgD0CuNVnCS//F2Vf0TmzZita3giC8KrS5yA==</Skey>\n</PidData>",
        "rdServicePackage": "com.mantra.mfs110.rdservice",
        "status": 1,
        "errInfo": "",
        "errorCode": 0,
        "message": "FingerPrint Scanned Successfully"
    }
    const aepsresponsepress = () => {
        navigation.navigate("AepsRespons", {
            ministate: {
                Date:'05/05/2002',
                openbal: 100,
                Type: 'saving',
                Amount: 2000,
                closebal: 1222,

            },
            mode: 'MINI'
        })
    };
    useEffect(() => {
        banks();
        checkAepsStatus();
        if (fingerprintData == 720) {
            if (fingerprintData === 720) {

                return;
            } else if (fingerprintData["PidData"].Resp.errCode === 0 && Proceed) {
                adhar_Validation(aadharNumber);
            }
        }
    }, [formattedDate]);

    const OnPressEnq = async () => {
        const pidData = fingerprintData.PidData;
        const DevInfo = pidData.DeviceInfo;
        const Resp = pidData.Resp;


        const cardnumberORUID = {
            adhaarNumber: aadharNumber,
            indicatorforUID: "0",
            nationalBankIdentificationNumber: bankid
        };

        const captureResponse = {
            Devicesrno: DevInfo.additional_info.Param[0].value,
            PidDatatype: "X",
            Piddata: pidData.Data.content,
            ci: pidData.Skey.ci,
            dc: DevInfo.dc,
            dpID: DevInfo.dpId,
            errCode: Resp.errCode,
            errInfo: Resp.errInfo,
            fCount: Resp.fCount,
            fType: Resp.fType,
            hmac: pidData.Hmac,
            iCount: Resp.fCount,
            iType: "0",
            mc: DevInfo.mc,
            mi: DevInfo.mi,
            nmPoints: Resp.nmPoints,
            pCount: "0",
            pType: "0",
            qScore: Resp.qScore,
            rdsID: DevInfo.rdsId,
            rdsVer: DevInfo.rdsVer,
            sessionKey: pidData.Skey.content
        };
      BEnQ(captureResponse, cardnumberORUID);
        try {
      
            // Alert.alert(
            //     'FingerPrint Done',
            //     'Scannned successfuly',
            //     [
            //       {
            //         text: 'continue',
            //         onPress: () => {
            //                                 },
            //       },
            //       {
            //         text: 'Cancel',
            //         style: 'cancel', 
            //       },
            //     ],
            //     { cancelable: false }
            //   );


        } catch (error) {
            console.error('Error during BEnQ:', error);
            Alert.alert('Error', 'An error occurred while processing your request. Please try again.');
        } finally {
            setIsLoading(true);
        }
    };
    const readLatLongFromStorage = async () => {
        try {
          const locationData = await AsyncStorage.getItem('locationData');
          
          if (locationData !== null) {
            const { latitude, longitude } = JSON.parse(locationData);
            console.log('Latitude:', latitude, 'Longitude:', longitude);
            return { latitude, longitude };
          } else {
            console.log('No location data found');
            return null;
          }
        } catch (error) {
          console.error('Failed to read location data from AsyncStorage:', error);
          return null; 
        }
      };
    
    const BEnQ = async (captureResponse1, cardnumberORUID1) => {

        const loc= await readLatLongFromStorage()
        setIsLoading(true);
        try {
            const Model = await getMobileDeviceId();
    
            const jdata = {
                captureResponse: captureResponse1,
                cardnumberORUID: cardnumberORUID1,
                languageCode: 'en',
                latitude: loc?.latitude,
                longitude: loc?.longitude,
                mobileNumber: mobileNumber,
                merchantTranId: userId,
                merchantTransactionId: userId,
                paymentType: 'B',
                otpnum: '',
                requestRemarks: 'TN3000CA06532',
                subMerchantId: 'A2zsuvidhaa',
                timestamp: formattedDate,
                name: consumerName,
                Address: 'Address',
                transactionAmount: ''
            };
    
            const headers = {
                'trnTimestamp': formattedDate,
                'deviceIMEI': Model,
                "Content-type": "application/json",
                "Accept": "application/json",
            };
    
            const data = JSON.stringify(jdata);
    
            const response = await post({
                url: 'AEPS/api/app/AEPS/MiniStatement',
                data:data,
                config: {
                    headers,
                },
            });
            // const path = RNFS.DownloadDirectoryPath + `/MiniStatement_${Date.now()}.json`; 
            // await RNFS.writeFile(path, JSON.stringify(response, null, 2), 'utf8')
            //     .then(() => {
            //         Alert.alert('Success', 'Response saved to Downloads folder');
            //     })
            //     .catch(err => {
            //         console.error('Error saving file:', err);
            //         Alert.alert('Error', 'Failed to save the file');
            //     });
            if (response) {
                const { RESULT, ADDINFO, agentid } = response;
                setFingerprintData(720);
    
                if (RESULT && RESULT.toString() === '0') {
                    setIsLoading(false);
                    setIsmodel(true);
                    setMinistate(ADDINFO);
    
                    // Save response to Download directory
              
    
                } else {
                    setIsLoading(false);
                    Alert.alert('Note:', ADDINFO || 'Unknown error occurred');
                }
            } else {
                setIsLoading(false);
                Alert.alert('Error', 'No response from server');
            }
    
        } catch (error) {
            setIsLoading(false);
            console.error('Error during balance enquiry:', error);
            Alert.alert('Error', 'Failed to process the request. Please try again later.');
        }
    };
    
    const MiniStatementResponse = ({ visible, onClose, statements }) => {
        const [isDarkMode, setIsDarkMode] = useState(Appearance.getColorScheme() === 'dark');
    
        useEffect(() => {
            const colorSchemeListener = Appearance.addChangeListener(({ colorScheme }) => {
                setIsDarkMode(colorScheme === 'dark');
            });
    
            // Cleanup listener on component unmount
            return () => colorSchemeListener.remove();
        }, []);
    
        return (
            <Modal transparent={true} visible={visible} animationType="slide">
                <View style={[styles.overlay, isDarkMode && styles.overlayDark]}>
                    <View style={[styles.container3, isDarkMode && styles.container3Dark]}>
                        <View style={styles.header}>
                            <Text style={[styles.title2, isDarkMode && styles.titleDark]}>Mini Statement Receipt</Text>
                        </View>
                        <View style={styles.listHeader}>
                            <Text style={[styles.headerText, isDarkMode && styles.headerTextDark]}>Date</Text>
                            <Text style={[styles.headerText, isDarkMode && styles.headerTextDark]}>Open</Text>
                            <Text style={[styles.headerText, isDarkMode && styles.headerTextDark]}>Type</Text>
                            <Text style={[styles.headerText, isDarkMode && styles.headerTextDark]}>Amount</Text>
                            <Text style={[styles.headerText, isDarkMode && styles.headerTextDark]}>Close</Text>
                        </View>
                        {statements && statements.length > 0 ? (
                            <FlatList
                                data={statements}
                                keyExtractor={(item) => item.id?.toString() || Math.random().toString()} // Handle undefined `id`
                                renderItem={({ item }) => (
                                    <View style={[styles.listItem, isDarkMode && styles.listItemDark]}>
                                        <Text style={isDarkMode && styles.textDark}>{item.Date || 'N/A'}</Text>
                                        <Text style={isDarkMode && styles.textDark}>{item.openbal || 'N/A'}</Text>
                                        <Text style={isDarkMode && styles.textDark}>{item.Type || 'N/A'}</Text>
                                        <Text style={isDarkMode && styles.textDark}>{item.Amount || 'N/A'}</Text>
                                        <Text style={isDarkMode && styles.textDark}>{item.closebal || 'N/A'}</Text>
                                    </View>
                                )}
                            />
                        ) : (
                            <View style={styles.emptyState}>
                                <Text style={[styles.emptyText, isDarkMode && styles.textDark]}>No statements available</Text>
                            </View>
                        )}
                        <View style={styles.footer}>
                            <TouchableOpacity style={[styles.button, isDarkMode && styles.buttonDark]} onPress={onClose}>
                                <Text style={[styles.buttonText2, isDarkMode && styles.buttonTextDark]}>Close</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        );
    };
    
    async function adhar_Validation(adharnumber) {
        try {
            const response = await get({ url: `${APP_URLS.aadharValidation}${adharnumber}` })
            console.log(response);

            // if (response['status'] === true){
            //                     setadharIsValid(true);

            // }else
            if (response['status'] === true) {
                setIsValid(true);
            } else {
                setIsValid(false);

                ToastAndroid.showWithGravity(
                    `Please Enter Valid Aadhar number`,
                    ToastAndroid.SHORT,
                    ToastAndroid.BOTTOM,
                );
            }
        } catch (error) {
        }
    }

    async function getUserNamefunction(MoNumber) {
        try {
            const response = await get({ url: `${APP_URLS.aepsNameinfo}${MoNumber}` })
            console.log(response);
            setAutofcs(true);
            setConsumerName(response.RESULT);
        } catch (error) {
            console.error('Error:', error);
        }
    }

    const checkvideo = async (transamount, agentid) => {
        try {
            const respone = post({ url: `${APP_URLS.checkadharpayvideo}transamount=${transamount}&agentid=${agentid}` });

            console.log(respone);
        } catch (error) {

        }
    };
    const checkAepsStatus = async () => {
        try {
            const respone = await get({ url: `${APP_URLS.checkaepsStatus}` });
            if (respone['Response'] === true) {
            } else {
                ToastAndroid.showWithGravity(
                    `${respone['Message']}`,
                    ToastAndroid.SHORT,
                    ToastAndroid.BOTTOM,
                );
            }
            console.log(respone['Response']);
            console.log(respone['Message']);

        } catch (error) {
            console.log(error);
        }
    };
    async function CaptureFinger() {
        console.log('ok')
    }
    const banks = async () => {
        try {
            const response = await post({ url: `${APP_URLS.aepsBanklist}` })
            console.log(response);

            if (response.RESULT === '0') {
                setBanklist(response['ADDINFO']['data'])
            }
        } catch (error) {
        }
    };
    const handleClose = () => {
        setIsVisible(false);
    };


    const payAadhar = () => {
        setIsVisible(false);
    };
    const handleUploadVideo = () => {
        setIsVisible(false);
    };
    const AepsVideoResponseDialog = ({ status, amount, date, bnkrrn, aadharNumber, agentid }) => {
        const [isVisible, setIsVisible] = useState(true);


        return (
            <Modal
                visible={isVisible}
                transparent
                animationType="slide"
                onRequestClose={() => setIsVisible(false)}
            >
                <View style={styles.container}>
                    <View style={styles.dialog}>
                        <Text style={styles.title}>Transaction Details</Text>
                        <Text style={styles.detailText}>Transaction Status: {status}</Text>
                        <Text style={styles.detailText}>Bank RRN: {bnkrrn}</Text>
                        <Text style={styles.detailText}>Date & Time: {date}</Text>
                        <Text style={styles.detailText}>Amount: ₹{amount}</Text>
                        <Text style={styles.detailText}>Aadhar Number: {aadharNumber}</Text>

                        <TouchableOpacity
                            style={styles.button}
                            onPress={handleUploadVideo}
                        >
                            <Text style={styles.buttonText}>Upload Video Now</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={[styles.button, { backgroundColor: '#dc3545' }]}
                            onPress={handleClose}
                        >
                            <Text style={styles.buttonText}>Close</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        );
    };


    const capture = async (rdServicePackage) => {
        let pidOptions = '';
        const aepscode = await AsyncStorage.getItem('aepscode');
        
        switch (rdServicePackage) {
          case 'com.mantra.mfs110.rdservice':
            pidOptions = '<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" posh="UNKNOWN" env="P" /> <CustOpts><Param name="mantrakey" value="" /></CustOpts> </PidOptions>';
            break;case 'com.mantra.rdservice':
            pidOptions = '<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" posh="UNKNOWN" env="P" /> <CustOpts><Param name="mantrakey" value="" /></CustOpts> </PidOptions>';
            break;
          case 'com.acpl.registersdk_l1':
            pidOptions = '<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" posh="UNKNOWN" env="P" wadh=""/> <CustOpts><Param name="" value="" /></CustOpts> </PidOptions>';
            break; case 'com.acpl.registersdk':
            pidOptions = '<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" posh="UNKNOWN" env="P" wadh=""/> <CustOpts><Param name="" value="" /></CustOpts> </PidOptions>';
            break;
          case 'com.idemia.l1rdservice':
            //pidOptions = '<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pCount="0" pgCount="2" format="0" pidVer="2.0" timeout="10000" pTimeout="20000" posh="UNKNOWN" env="P" /> <Demo></Demo> <CustOpts><Param name="" value="" /></CustOpts> </PidOptions>';
            pidOptions =`<PidOptions ver="1.0"><Opts env="P" fCount="1" fType="2" iCount="0" iType="" pCount="0" pType="" format="0" pidVer="2.0" timeout="20000" wadh="" posh="UNKNOWN" /><Demo></Demo><CustOpts><Param name="" value="" /></CustOpts></PidOptions>`;
            break; case 'com.scl.rdservice':
           // pidOptions = '<PidOptions ver="1.0"> <Opts fCount="1" fType="2" iCount="0" pType="" pCount="0"  format="0" pidVer="2.0" timeout="20000"  posh="UNKNOWN" env="P" /> <Demo></Demo> <CustOpts><Param name="" value="" /></CustOpts> </PidOptions>';
            pidOptions =`<PidOptions ver="1.0"><Opts env="P" fCount="1" fType="2" iCount="0" iType="" pCount="0" pType="" format="0" pidVer="2.0" timeout="20000" wadh="" posh="UNKNOWN" /><Demo></Demo><CustOpts><Param name="" value="" /></CustOpts></PidOptions>`;
            break;
          default:
            console.error('Unsupported rdServicePackage');
            return;
        }
    
        openFingerPrintScanner(rdServicePackage, pidOptions)

          .then(async(res) => {
            const deviceInfoString = JSON.stringify(res, null, 2);
           // await post({ url: 'AEPS/api/Aeps/ErrorMessage', data: { Message: JSON.stringify(res) } });
    
            // const path = RNFS.DownloadDirectoryPath + `/deviceInfo-capture-today--Finger.json`;
    
            // Write the response to a file
            // RNFS.writeFile(path, deviceInfoString, 'utf8')
            //   .then(() => {
            //     console.log('JSON saved to Download directory');
            //   })
            //   .catch((error) => {
            //     console.error('Error writing file:', error);
            //     // Alert.alert('Error', 'Failed to save file');
            //   });
    
            // Handle different response cases
            if (res.errorCode === 720) {
              setFingerprintData(720);
              console.log('setFingerprintData', res.errInfo, res.message);
            } else if (res.status === -1) {
              setFingerprintData(-1);
            } else if (res.errorCode === 0) {
    
                OnPressEnq(res.pidDataJson);
              console.log('setFingerprintData', res);
    
              const responseString = JSON.stringify(res.pidDataJson, null, 2);
              //    Alert.alert('Tab Fingerprint Data', responseString);
            
            }
          })
          .catch(async(error) => {
            // await post({ url: 'AEPS/api/Aeps/ErrorMessage', data: { Message: JSON.stringify({
            //   message: error?.message,
            //   line: error?.line,
            //   column: error?.column
            // }) } });
            setFingerprintData(720);
            Alert.alert('Please check if the device is connected.');
          });
      };
    const handleSelection = (selectedOption) => {
        if (selectedOption === 'Device') {
          ToastAndroid.showWithGravity('Please Select Your Device', ToastAndroid.SHORT, ToastAndroid.BOTTOM);
          return;
        }
      console.log(selectedOption)
        const captureMapping = {
          'mantra L0': 'com.mantra.rdservice',
          'mantra L1': 'com.mantra.mfs110.rdservice',
          'startek L0': 'com.acpl.registersdk',
          'startek L1': 'com.acpl.registersdk_l1',
          'morpho L0': 'com.scl.rdservice',
          'morpho L1': 'com.idemia.l1rdservice',
        };
        
      console.log(captureMapping[selectedOption])
        if (captureMapping[selectedOption]) {
          isDriverFound(captureMapping[selectedOption])
            .then((res) => {
              console.log(res); 
  if(isDeviceConnected){
                    console.log(isDeviceConnected,'#####');
         capture(captureMapping[selectedOption]);
                  }else{
                    ToastAndroid.showWithGravityAndOffset(
                      res.message + '  But Device Not Connected',
                      ToastAndroid.LONG,
                      ToastAndroid.TOP,
                      0,
                      1000
                    );
                  }    
    
            //  alert(`Capture Mapping: ${captureMapping[selectedOption]}\nResponse: ${JSON.stringify(res)}`);
          
            })
            .catch((error) => {
              console.error('Error finding driver:', error);
              alert('Error: Could not find the selected driver.');
            });
        } else {
          alert('Invalid option selected');
        }
      };


      const onSuccess = (e) => {
        console.log(e);
        setisScan2(false);
        const data = e.data;
        
        const obj = {};
        const regex = /([a-zA-Z0-9]+)="([^"]+)"/g;
        let match;
        
        while ((match = regex.exec(data)) !== null) {
          obj[match[1]] = match[2];
        }
     setAadharNumber(obj.uid)
     setConsumerName(obj.name)
        console.log(obj)
        // Linking.openURL(e.data).catch((err) => console.error('An error occurred', err));
    };
    const [isScan2, setisScan2] = useState(false)
   if (isScan2) {
         return   <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
         <View style={{ alignItems: 'center', position: 'absolute', top: 30, right: 20 }}>
           <TouchableOpacity
             onPress={() => setisScan2(false)}
             style={{
               backgroundColor: '#ff4d4d',
               padding: 10,
               borderRadius: 10,
               width:hScale(40),
               height:hScale(40),
               alignItems: 'center',
             }}
           >
             <Text style={{ color: 'white', fontSize: 20 }}>X</Text>
           </TouchableOpacity>
         </View>
 
         {/* QR Code Scanner */}
         <QRCodeScanner onRead={onSuccess} />
       </View>
     }
    return (
        <View style={styles.main}>

            <ScrollView>
                <View style={styles.container}>
                    <View style={styles.body}>

                       
                    <View style={{}}>

<FlotingInput
    label="Enter Aadhar Number"
    value={aadharNumber}
    maxLength={12}
    onChangeText={setAadharNumber}
    keyboardType="numeric"
    onChangeTextCallback={(text) => {
        setAadharNumber(text);
        if (text.length === 12) {
            adhar_Validation(text)
        } else {
            setIsValid(false)

        }

    }}
/>

<View style={[styles.righticon2]}>

    <TouchableOpacity
        onPress={() => {
            setisScan2(true)
        }}
    >
        <QrcodAddmoneysvg />

    </TouchableOpacity>
</View>
</View>


                        <FlotingInput
                            label="Enter Mobile Number"
                            value={mobileNumber}
                            onChangeText={setMobileNumber}
                            keyboardType="numeric"
                            onChangeTextCallback={(text) => {
                                setMobileNumber(text);
                                if (text.length === 10) {
                                    getUserNamefunction(text);
                                }
                                if (mobileNumber.length === 10) {
                                    setAutofcs(false);
                                } else {

                                }

                            }}

                        />
                        <FlotingInput
                            label="Enter Consumer Name"
                            value={consumerName}
                            onChangeText={setConsumerName}
                            autoFocus={autofcs}
                            onChangeTextCallback={(text) => {
                                setConsumerName(text);


                            }}


                        />
                        <TouchableOpacity
                            style={{}}
                            onPress={() => { setisbank(true) }}
                        >
                            <>
                                <FlotingInput
                                    editable={false}
                                    label={bankName.toString()}
                                    onChangeText={setServifee}
                                    placeholder={bankName ? "" : "Select Bank"}
                                    keyboardType="numeric"
                                    onChangeTextCallback={(text) => {
                                        setServifee(text);
                                    }}
                                    inputstyle={styles
                                        .inputstyle
                                    }
                                />
                            </>
                            <View style={styles.righticon}>
                                <OnelineDropdownSvg />
                            </View>
                        </TouchableOpacity>
                        <SelectDevice setDeviceName={setDeviceName} device={'Device'} opPress={()=>{setDeviceName(deviceName);}}/>


                        <View style={{ marginBottom: hScale(10) }} />


                        {otpservisi && (
                            <FlotingInput
                                label="Enter OTP"
                                value={otpcontroller}
                                onChangeText={setOtpcontroller}
                                keyboardType="numeric"
                                onChangeTextCallback={(text) => {
                                    setOtpcontroller(text);

                                }}
                            />
                        )}





                        <TouchableOpacity
                            style={{}}
                        >
                            <DynamicButton
                                onPress={() => {
                                    if (bankName === 'Select Bank' || mobileNumber.length < 10 || consumerName === null || aadharNumber.length < 12) {
                                        console.log('Select Bank', fingerprintData == 720);
                                    } else {

                                        handleSelection(deviceName)
                                        // if (fingerprintData == 720) {
                                        //     setIsScan(true);
                                        //     scanFingerprint();
                                        //     console.log('scanFingerprint', fingerprintData == 720);
                                        // } else {
                                        //     OnPressEnq();
                                        //     setProceed(true);
                                        //     console.log('scanFingerprint', fingerprintData == 720);

                                        // }
                                        // console.log('ok')
                                    }
                                }}

                                //onPress={CaptureFinger}
                                title={<Text>{'Scan & Proceed'}
                                </Text>}
                            />
                        </TouchableOpacity>



                        {isLoading ? (
                            <ShowLoader />
                        ) : null}

                        {showDialog && (
                            <AepsVideoResponseDialog
                                status={status}
                                amount={amount}
                                date={date}
                                bnkrrn={bnkrrn}
                                aadharnum={aadharNumber}
                                agentid={agentid}
                            />
                        )}
                    </View>
                    {/* <TouchableOpacity onPress={aepsresponsepress}>
                <Text style={{ color: 'red' }}>
                    Aeps Respons
                </Text>
            </TouchableOpacity> */}
                </View>
            </ScrollView>
            <MiniStatementResponse
                visible={ismodel}
                onClose={() => setIsmodel(false)}
                statements={ministate}
            />
            <BankBottomSite
                setBankId={setBankId}

                bankdata={banklist}
                isbank={isbank}
                setBankName={setBankName}
                setisbank={setisbank}
            />

        </View>
    );
};
const styles = StyleSheet.create({
    righticon2: {
        position: "absolute",
        left: "auto",
        right: wScale(0),
        top: hScale(0),
        height: "85%",
        alignItems: "flex-end",
        justifyContent: "center",
        paddingRight: wScale(12),
        width: wScale(44),
        marginRight: wScale(-2),
    },
    main: {
        flex: 1,
    },
    container: {
        backgroundColor: '#FFFFFF',
        paddingHorizontal: 20, // Adjust as needed
        flex: 1,
        paddingBottom: 20,
    },
    container2: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)', // Light overlay for modals
    },
    dialog: {
        backgroundColor: '#fff',
        padding: 20,
        borderRadius: 10,
        width: '80%',
        elevation: 5,
        shadowColor: '#000',
        shadowOpacity: 0.3,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 5,
    },
    title: {
        fontWeight: 'bold',
        fontSize: 18,
        marginBottom: 10,
        color: '#007bff',
    },
    detailText: {
        marginBottom: 5,
        fontSize: 16,
    },
    button: {
        backgroundColor: '#28a745',
        padding: 10,
        borderRadius: 5,
        marginTop: 10,
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    body: {
        paddingTop: 10,
    },
    inputstyle: {
        marginBottom: 0,
    },
    overlay: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.8)', // Default dark overlay for modal
    },
    overlayDark: {
        backgroundColor: 'rgba(0, 0, 0, 0.9)', // Darker overlay for dark mode
    },
    container3: {
        backgroundColor: 'white',
        borderRadius: 8,
        marginHorizontal: 20,
    },
    container3Dark: {
        backgroundColor: '#333', // Dark background for dark mode
    },
    header: {
        alignItems: 'center',
        marginBottom: 10,
    },
    title2: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    titleDark: {
        color: 'white', // Dark mode title color
    },
    listHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
        fontWeight: 'bold',
    },
    headerText: {
        flex: 1,
        textAlign: 'center',
    },
    headerTextDark: {
        color: '#ddd', // Lighter text for dark mode
    },
    listItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 5,
    },
    listItemDark: {
        backgroundColor: '#444', // Darker background for dark mode
    },
    footer: {
        marginTop: 10,
        alignItems: 'flex-end',
    },
    button2: {
        padding: 10,
        backgroundColor: '#007BFF',
        borderRadius: 5,
    },
    buttonText2: {
        color: 'white',
    },
    buttonTextDark: {
        color: '#fff', // Button text color in dark mode
    },
    textDark: {
        color: '#ddd', // Light text for dark mode
    },
    righticon: {
        position: 'absolute',
        left: 'auto',
        right: 12, // Adjusted with wScale
        top: 0, // Adjusted with hScale
        height: '100%',
        alignItems: 'flex-end',
        justifyContent: 'center',
        paddingRight: 12, // Adjusted with wScale
    },
    // Additional styles for handling dark mode
    emptyState: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
    },
    emptyText: {
        color: '#888', // Default light gray for empty state text
    },
    emptyTextDark: {
        color: '#bbb', // Lighter text for empty state in dark mode
    },
    // Button styles
    buttonDark: {
        backgroundColor: '#1b5e20', // Darker green for dark mode
    },
    buttonText2Dark: {
        color: '#fff', // White text for button in dark mode
    },
    // Input field styles
    inputField: {
        padding: 10,
        marginVertical: 10,
        borderRadius: 5,
    },
    inputFieldDark: {
        backgroundColor: '#555', // Dark background for inputs in dark mode
        color: '#ddd', // Light text color in inputs for dark mode
    },
    label: {
        fontWeight: 'bold',
        color: '#333',
    },
    labelDark: {
        color: '#fff', // Light label for dark mode
    },
    // More specific text styling
    normalText: {
        color: '#333',
    },
    normalTextDark: {
        color: '#ddd', // Lighter text for dark mode
    },
    modalTitle: {
        fontWeight: 'bold',
        fontSize: 20,
        color: '#007bff',
    },
    modalTitleDark: {
        color: '#f0f0f0', // Light color for modal title in dark mode
    },
});

export default AepsMinistatement;

