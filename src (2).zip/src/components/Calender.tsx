import React from 'react';
import { View, StyleSheet } from 'react-native';
import CalendarPicker from 'react-native-calendar-picker';
import LinearGradient from 'react-native-linear-gradient';
import moment from 'moment'
import { useSelector } from 'react-redux';
import { RootState } from '../reduxUtils/store';
const CustomCalendar = ({ onDateSelected }) => {
  const { colorConfig } = useSelector((state: RootState) => state.userInfo)
  const handleDateChange = (date: any) => {
    const formattedDate = moment(date).format('YYYY-MM-DD');
    console.log(formattedDate);
    onDateSelected(formattedDate)
  };

  return (
    <View style={[styles.container, { backgroundColor: colorConfig.secondaryColor }]}>

      <CalendarPicker
        onDateChange={handleDateChange}
        previousTitle={'<'}
        nextTitle={'>'}
        selectedDayColor={"red"}
        
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
   borderTopEndRadius:10,
   borderTopLeftRadius:10,
   flex:1
  },
 
});

export default CustomCalendar;
