import React, { useState } from "react";
import { View, Text, Image, StyleSheet } from "react-native";
import { useSelector } from "react-redux";
import { RootState } from "../../reduxUtils/store";
import { hScale, wScale } from "../../utils/styles/dimensions";
import CountdownTimer from "../dashboard/components/ContdownTimer";
import { useNavigation } from "../../utils/navigation/NavigationService";
import ShowLoderTr from "../../components/ShowLoderTr";
import QrcodeExpiredSvg from "../drawer/svgimgcomponents/QrcodeExpiredSvg";


export default function PaymentQR({ QrImg, amnt }) {
    const { colorConfig } = useSelector((state: RootState) => state.userInfo);
    const navigation = useNavigation<any>();
    const [isExpired, setIsExpired] = useState(false);
    const [showLoader, setShowLoader] = useState(false);
    const handleExpire = () => {
        setIsExpired(true);

        // Show loader for 2 seconds before showing expired message
        setTimeout(() => {
            navigation.goBack()
        }, 2000);
    };
    return (
        <View style={styles.container}>

            <View style={[styles.topHalf,]}
            />

            <View style={[styles.bottomHalf, { backgroundColor: colorConfig.secondaryColor }]} />

            <View style={styles.centerContent}>
                <Text style={styles.title}>Scan This Amount</Text>
                <Text style={[styles.subtitle, { backgroundColor: colorConfig.secondaryColor }]}>₹ {amnt}</Text>

                <View style={styles.qrBox}>
                    {showLoader ? (
                        <ShowLoderTr />
                    ) : !isExpired ? (
                        QrImg ? (
                            <Image source={{ uri: QrImg }} style={styles.qrImage} />
                        ) : (
                            <ShowLoderTr />
                        )
                    ) :
                        <View style={{ alignItems: 'center' }}>
                            <QrcodeExpiredSvg />
                            <Text style={[styles.expired, { color: '#000' }]}>your QR is expired</Text>

                        </View>
                    }
                </View>

                {QrImg && !isExpired && (
                    <CountdownTimer onComplete={handleExpire} initialTime={125} />
                )}

                {isExpired &&


                    <Text style={styles.disc}>
                        Regenerate The QR CODE if You Need to add a New Payment
                    </Text>
                }
            </View>

        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

    topHalf: {
        flex: 1,
        backgroundColor: "#eeede4",
        width: "100%",
    },

    bottomHalf: {
        flex: 1,
        backgroundColor: "#F25E3D",
        width: "100%",
    },

    centerContent: {
        position: "absolute",
        top: "35%",                    // was "40%"
        left: 0,
        right: 0,
        transform: [{ translateY: -hScale(150) }],
        alignItems: "center",
        zIndex: 99,
    },

    title: {
        fontSize: wScale(25),
        fontWeight: "bold",
        color: "#1C3C77",
        alignSelf: 'center',
        textTransform: 'uppercase'
    },
    expired: {
        fontSize: wScale(25),
        fontWeight: "bold",
        color: "#1C3C77",
        alignSelf: 'center',
        textTransform: 'uppercase',
        marginTop: hScale(10)
    },
    disc: {
        fontSize: wScale(18),
        alignSelf: 'center',
        color: '#fff',
        textAlign: 'center',
        paddingHorizontal: wScale(33),
        textTransform: 'uppercase',
        marginTop: hScale(10)
    },

    subtitle: {
        marginTop: hScale(8),
        backgroundColor: "#FF6A4D",
        color: "white",
        paddingHorizontal: wScale(20),
        paddingVertical: hScale(6),
        borderRadius: wScale(10),
        fontWeight: "bold",
        fontSize: wScale(32),
    },

    qrBox: {
        marginTop: hScale(20),
        backgroundColor: "white",
        borderRadius: wScale(12),
        width: wScale(315),
        height: wScale(315),
        marginBottom: hScale(10),
        alignItems: 'center',
        justifyContent: 'center'

    },

    qrImage: {
        width: wScale(315),
        height: wScale(315),
        resizeMode: "contain",
        borderRadius: wScale(12),
        alignItems: 'center',
        alignSelf: 'center'

    },
});
